#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "load_window.h"
#include <string.h>


void on_button1_clicked (GtkButton *button,gpointer user_data)
{
GtkWidget *window1;
window1=lookup_widget(button,"window1");
gtk_widget_hide(window1);
GtkWidget *window2;
window2 = create_window2 ();
gtk_widget_show (window2);
}


void on_button2_clicked(GtkButton *button,gpointer user_data)
{
GtkWidget *window1;
window1=lookup_widget(button,"window1");
gtk_widget_hide(window1);
GtkWidget *window5;
window5 =create_window5 ();
gtk_widget_show (window5);
}










void on_button6_clicked(GtkButton *button,gpointer user_data)
{
GtkWidget *window3;
window3=lookup_widget(button,"window3");
gtk_widget_hide(window3);
GtkWidget *window2;
window2 =create_window2 ();
gtk_widget_show (window2);
}


void on_button4_clicked (GtkButton *button, gpointer user_data)
{
GtkWidget *window2 , *output;
FILE*f;
//char ch1[400],ch2[300],ch3[100];
gchar buff[1024];
window2=lookup_widget(button,"window2");
gtk_widget_hide(window2);
GtkWidget *window4;
window4 =create_window4 ();
gtk_widget_show (window4);
/*buff=lookup_widget(window4,"textview1");
f=fopen("international.txt","r");
//gchar buff[1024];
gsize size;
if (g_file_get_contents("international.txt", &buff, &size, NULL))
{
     gtk_label_set_text ( buff );
}
fclose(f);*/
}


void on_button8_clicked(GtkButton *button, gpointer user_data)
{
GtkWidget *window4;
window4=lookup_widget(button,"window4");
gtk_widget_hide(window4);
GtkWidget *window2;
window2 =create_window2 ();
gtk_widget_show (window2);
}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
window2=lookup_widget(button,"window2");
gtk_widget_hide(window2);
GtkWidget *window1;
window1 =create_window1 ();
gtk_widget_show (window1);
}


void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5;
window5=lookup_widget(button,"window5");
gtk_widget_hide(window5);
GtkWidget *window1;
window1 =create_window1 ();
gtk_widget_show (window1);
}


void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5;
window5=lookup_widget(button,"window5");
gtk_widget_hide(window5);
GtkWidget *window6;
window6 =create_window6 ();
gtk_widget_show (window6);
}



void
on_button17_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6;
window6=lookup_widget(button,"window6");
gtk_widget_hide(window6);
GtkWidget *window5;
window5 =create_window5 ();
gtk_widget_show (window5);
}





void on_button16_clicked (GtkButton *button, gpointer user_data)
{
GtkWidget *input1,*input2,*output;
GtkWidget *window6;
window6=lookup_widget(button,"window6");
int tst=0;
FILE*f;
//gtk_entry_set_invisible_char (GTK_ENTRY ("entry1"),8226);
char username[100],password[100],user[100],pass[100];
input1=lookup_widget(button,"entry1");
input2=lookup_widget(button,"entry2");
output=lookup_widget(button,"label20");

strcpy(username,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2)));
f=fopen("adminpass.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %s",user,pass)!=EOF){
if(strcmp(username,user)==0 && strcmp(password,pass)==0){
tst++;
}
}
}fclose(f);
if(tst==0){
gtk_label_set_text(GTK_LABEL(output),"nom d'utilisateur ou mot de passe incorrect");
gtk_entry_set_text(GTK_ENTRY(input2),"");
gtk_entry_set_text(GTK_ENTRY(input1),"");
}


else {
gtk_widget_hide(window6);
GtkWidget *window7;
window7= create_window7 ();
gtk_widget_show (window7);

}
}


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)

{
GtkWidget *window2 , *output;
FILE*f;
char ch1[400],ch2[400],ch3[400],ch4[400],ch11[10000]={0},ch22[10000]={0},ch33[10000]={0},ch44[10000]={0};
window2=lookup_widget(button,"window2");
gtk_widget_hide(window2);
GtkWidget *window3;
window3 = create_window3 ();
gtk_widget_show (window3);
output=lookup_widget(window3,"label2");
f=fopen("creation.txt","r");
if(f!=NULL){
while (fgets(ch1,400,f)!=NULL)//(f,"%s",ch1)!=EOF)
{strcat(ch11,ch1);
strcat(ch11,"\n");
}
fclose(f);
gtk_label_set_text(GTK_LABEL(output),ch11);}

output=lookup_widget(window3,"label4");
f=fopen("ad.txt","r");
if(f!=NULL){
while (fgets(ch2,400,f)!=NULL)//(f,"%s",ch1)!=EOF)
{strcat(ch22,ch2);
strcat(ch22,"\n");
}
fclose(f);
gtk_label_set_text(GTK_LABEL(output),ch22);}
output=lookup_widget(window3,"label6");
f=fopen("equi.txt","r");
if(f!=NULL){
while (fgets(ch3,400,f)!=NULL)//(f,"%s",ch1)!=EOF)
{strcat(ch33,ch3);
strcat(ch33,"\n");
}
fclose(f);
gtk_label_set_text(GTK_LABEL(output),ch33);}
output=lookup_widget(window3,"label8");
f=fopen("spec.txt","r");
if(f!=NULL){
while (fgets(ch4,400,f)!=NULL)//(f,"%s",ch1)!=EOF)
{strcat(ch44,ch4);
strcat(ch44,"\n");}
fclose(f);
gtk_label_set_text(GTK_LABEL(output),ch44);}
}


