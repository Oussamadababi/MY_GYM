void load_window (GtkLabel *l ,FILE *f ,char ch1[]);
