#include <gtk/gtk.h>
#include <stdlib.h>
#include <stdio.h>
void load_window (GtkLabel *l ,FILE *f,char ch1[]){
f=fopen("creation.txt","r");
if(f!=NULL){
fscanf(f,"%s",ch1);
gtk_label_set_text(l,ch1);}
fclose(f);}
