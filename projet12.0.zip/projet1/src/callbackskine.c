#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>

#include <gdk/gdkkeysyms.h>
#include <gtk/gtk.h>

#include "callbackskine.h"
//#include "interface.h"
#include "support.h"

#define GLADE_HOOKUP_OBJECT(component,widget,name) \
  g_object_set_data_full (G_OBJECT (component), name, \
    gtk_widget_ref (widget), (GDestroyNotify) gtk_widget_unref)

#define GLADE_HOOKUP_OBJECT_NO_REF(component,widget,name) \
  g_object_set_data (G_OBJECT (component), name, widget)

GtkWidget*
create_windowkine (void)
{
  GtkWidget *window1;
  GtkWidget *notebook1;
  GtkWidget *fixed1;
  GtkWidget *label7;
  GtkWidget *label11;
  GtkWidget *label18;
  GtkWidget *label12;
  GtkWidget *label8;
  GtkWidget *label15;
  GtkWidget *label28;
  GtkWidget *label13;
  GtkWidget *label16;
  GtkWidget *label9;
  GtkWidget *label10;
  GtkWidget *label5;
  GtkWidget *label6;
  GtkWidget *label99;
  GtkWidget *bt_editprofil;
  GtkWidget *alignment3;
  GtkWidget *hbox3;
  GtkWidget *image4;
  GtkWidget *label107;
  GtkWidget *bt_disconnect;
  GtkWidget *alignment4;
  GtkWidget *hbox4;
  GtkWidget *image5;
  GtkWidget *label108;
  GtkWidget *label_1;
  GtkWidget *fixed2;
  GtkObject *spinbutton1_adj;
  GtkWidget *spinbutton1;
  GtkObject *spinbutton2_adj;
  GtkWidget *spinbutton2;
  GtkObject *spinbutton3_adj;
  GtkWidget *spinbutton3;
  GtkWidget *label100;
  GtkWidget *label101;
  GtkWidget *label102;
  GtkWidget *combobox1;
  GtkWidget *label103;
  GtkWidget *treeview2;
  GtkWidget *label104;
  GtkWidget *button9k;
  GtkWidget *alignment5;
  GtkWidget *hbox5;
  GtkWidget *image6;
  GtkWidget *label109;
  GtkWidget *button10k;
  GtkWidget *alignment6;
  GtkWidget *hbox6;
  GtkWidget *image7;
  GtkWidget *label110;
  GtkWidget *label2;
  GtkWidget *fixed3;
  GtkWidget *treeview1;
  GtkWidget *label3;
  GtkWidget *fixed4;
  GtkWidget *button6;
  GtkWidget *alignment7;
  GtkWidget *hbox7;
  GtkWidget *image8;
  GtkWidget *label111;
  GtkWidget *button7;
  GtkWidget *alignment8;
  GtkWidget *hbox8;
  GtkWidget *image9;
  GtkWidget *label112;
  GtkWidget *label4;
  GtkWidget *fixed5;
  GtkWidget *label17;

  window1 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window1), _("window1"));

  notebook1 = gtk_notebook_new ();
  gtk_widget_show (notebook1);
  gtk_container_add (GTK_CONTAINER (window1), notebook1);

  fixed1 = gtk_fixed_new ();
  gtk_widget_show (fixed1);
  gtk_container_add (GTK_CONTAINER (notebook1), fixed1);

  label7 = gtk_label_new (_("Name  :"));
  gtk_widget_show (label7);
  gtk_fixed_put (GTK_FIXED (fixed1), label7, 0, 312);
  gtk_widget_set_size_request (label7, 88, 33);

  label11 = gtk_label_new (_("Email :"));
  gtk_widget_show (label11);
  gtk_fixed_put (GTK_FIXED (fixed1), label11, 0, 488);
  gtk_widget_set_size_request (label11, 80, 16);

  label18 = gtk_label_new (_("Adresse"));
  gtk_widget_show (label18);
  gtk_fixed_put (GTK_FIXED (fixed1), label18, 16, 536);
  gtk_widget_set_size_request (label18, 57, 16);

  label12 = gtk_label_new (_("*******@***.**"));
  gtk_widget_show (label12);
  gtk_fixed_put (GTK_FIXED (fixed1), label12, 144, 472);
  gtk_widget_set_size_request (label12, 224, 48);

  label8 = gtk_label_new (_("********"));
  gtk_widget_show (label8);
  gtk_fixed_put (GTK_FIXED (fixed1), label8, 112, 304);
  gtk_widget_set_size_request (label8, 248, 41);

  label15 = gtk_label_new (_("Bio :"));
  gtk_widget_show (label15);
  gtk_fixed_put (GTK_FIXED (fixed1), label15, 16, 672);
  gtk_widget_set_size_request (label15, 57, 16);

  label28 = gtk_label_new (_("label28"));
  gtk_widget_show (label28);
  gtk_fixed_put (GTK_FIXED (fixed1), label28, 200, 536);
  gtk_widget_set_size_request (label28, 288, 16);

  label13 = gtk_label_new (_("Date of birth :"));
  gtk_widget_show (label13);
  gtk_fixed_put (GTK_FIXED (fixed1), label13, 0, 368);
  gtk_widget_set_size_request (label13, 128, 32);

  label16 = gtk_label_new (_("*******************************************\n******************************\n**************************\n**********************\n************************"));
  gtk_widget_show (label16);
  gtk_fixed_put (GTK_FIXED (fixed1), label16, 128, 576);
  gtk_widget_set_size_request (label16, 344, 208);

  label9 = gtk_label_new (_("Phone Number :"));
  gtk_widget_show (label9);
  gtk_fixed_put (GTK_FIXED (fixed1), label9, 0, 432);
  gtk_widget_set_size_request (label9, 144, 16);

  label10 = gtk_label_new (_("99999999"));
  gtk_widget_show (label10);
  gtk_fixed_put (GTK_FIXED (fixed1), label10, 128, 416);
  gtk_widget_set_size_request (label10, 224, 48);

  label5 = gtk_label_new (_("First Name  :"));
  gtk_widget_show (label5);
  gtk_fixed_put (GTK_FIXED (fixed1), label5, 16, 248);
  gtk_widget_set_size_request (label5, 88, 40);

  label6 = gtk_label_new ("");
  gtk_widget_show (label6);
  gtk_fixed_put (GTK_FIXED (fixed1), label6, 128, 248);
  gtk_widget_set_size_request (label6, 216, 40);

  label99 = gtk_label_new (_("dd/mm/yyyy"));
  gtk_widget_show (label99);
  gtk_fixed_put (GTK_FIXED (fixed1), label99, 184, 376);
  gtk_widget_set_size_request (label99, 128, 16);

  bt_editprofil = gtk_button_new ();
  gtk_widget_show (bt_editprofil);
  gtk_fixed_put (GTK_FIXED (fixed1), bt_editprofil, 1368, 72);
  gtk_widget_set_size_request (bt_editprofil, 170, 64);

  alignment3 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_show (alignment3);
  gtk_container_add (GTK_CONTAINER (bt_editprofil), alignment3);

  hbox3 = gtk_hbox_new (FALSE, 2);
  gtk_widget_show (hbox3);
  gtk_container_add (GTK_CONTAINER (alignment3), hbox3);

  image4 = gtk_image_new_from_stock ("gtk-edit", GTK_ICON_SIZE_BUTTON);
  gtk_widget_show (image4);
  gtk_box_pack_start (GTK_BOX (hbox3), image4, FALSE, FALSE, 0);

  label107 = gtk_label_new_with_mnemonic (_("Edit"));
  gtk_widget_show (label107);
  gtk_box_pack_start (GTK_BOX (hbox3), label107, FALSE, FALSE, 0);

  bt_disconnect = gtk_button_new ();
  gtk_widget_show (bt_disconnect);
  gtk_fixed_put (GTK_FIXED (fixed1), bt_disconnect, 1368, 720);
  gtk_widget_set_size_request (bt_disconnect, 170, 69);

  alignment4 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_show (alignment4);
  gtk_container_add (GTK_CONTAINER (bt_disconnect), alignment4);

  hbox4 = gtk_hbox_new (FALSE, 2);
  gtk_widget_show (hbox4);
  gtk_container_add (GTK_CONTAINER (alignment4), hbox4);

  image5 = gtk_image_new_from_stock ("gtk-cancel", GTK_ICON_SIZE_BUTTON);
  gtk_widget_show (image5);
  gtk_box_pack_start (GTK_BOX (hbox4), image5, FALSE, FALSE, 0);

  label108 = gtk_label_new_with_mnemonic (_("Disconnect"));
  gtk_widget_show (label108);
  gtk_box_pack_start (GTK_BOX (hbox4), label108, FALSE, FALSE, 0);

  label_1 = gtk_label_new (_("Profil "));
  gtk_widget_show (label_1);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook1), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook1), 0), label_1);

  fixed2 = gtk_fixed_new ();
  gtk_widget_show (fixed2);
  gtk_container_add (GTK_CONTAINER (notebook1), fixed2);

  spinbutton1_adj = gtk_adjustment_new (1, 1, 31, 1, 10, 10);
  spinbutton1 = gtk_spin_button_new (GTK_ADJUSTMENT (spinbutton1_adj), 1, 0);
  gtk_widget_show (spinbutton1);
  gtk_fixed_put (GTK_FIXED (fixed2), spinbutton1, 120, 40);
  gtk_widget_set_size_request (spinbutton1, 60, 27);

  spinbutton2_adj = gtk_adjustment_new (1, 1, 12, 1, 10, 10);
  spinbutton2 = gtk_spin_button_new (GTK_ADJUSTMENT (spinbutton2_adj), 1, 0);
  gtk_widget_show (spinbutton2);
  gtk_fixed_put (GTK_FIXED (fixed2), spinbutton2, 280, 40);
  gtk_widget_set_size_request (spinbutton2, 60, 27);

  spinbutton3_adj = gtk_adjustment_new (1, 2018, 2050, 1, 10, 10);
  spinbutton3 = gtk_spin_button_new (GTK_ADJUSTMENT (spinbutton3_adj), 1, 0);
  gtk_widget_show (spinbutton3);
  gtk_fixed_put (GTK_FIXED (fixed2), spinbutton3, 440, 40);
  gtk_widget_set_size_request (spinbutton3, 60, 27);

  label100 = gtk_label_new (_("Day :"));
  gtk_widget_show (label100);
  gtk_fixed_put (GTK_FIXED (fixed2), label100, 64, 48);
  gtk_widget_set_size_request (label100, 57, 17);

  label101 = gtk_label_new (_("Month :"));
  gtk_widget_show (label101);
  gtk_fixed_put (GTK_FIXED (fixed2), label101, 216, 48);
  gtk_widget_set_size_request (label101, 57, 17);

  label102 = gtk_label_new (_("Year :"));
  gtk_widget_show (label102);
  gtk_fixed_put (GTK_FIXED (fixed2), label102, 376, 48);
  gtk_widget_set_size_request (label102, 57, 17);

  combobox1 = gtk_combo_box_new_text ();
  gtk_widget_show (combobox1);
  gtk_fixed_put (GTK_FIXED (fixed2), combobox1, 232, 104);
  gtk_widget_set_size_request (combobox1, 232, 48);
  gtk_combo_box_append_text (GTK_COMBO_BOX (combobox1), _("10h ==>12h"));
  gtk_combo_box_append_text (GTK_COMBO_BOX (combobox1), _("16h ==>18h"));

  label103 = gtk_label_new (_("Reservation hour :"));
  gtk_widget_show (label103);
  gtk_fixed_put (GTK_FIXED (fixed2), label103, 64, 88);
  gtk_widget_set_size_request (label103, 168, 72);

  treeview2 = gtk_tree_view_new ();
  gtk_widget_show (treeview2);
  gtk_fixed_put (GTK_FIXED (fixed2), treeview2, 200, 328);
  gtk_widget_set_size_request (treeview2, 300, 200);

  label104 = gtk_label_new ("");
  gtk_widget_show (label104);
  gtk_fixed_put (GTK_FIXED (fixed2), label104, 176, 264);
  gtk_widget_set_size_request (label104, 352, 40);

  button9k = gtk_button_new ();
  gtk_widget_show (button9k);
  gtk_fixed_put (GTK_FIXED (fixed2), button9k, 192, 200);
  gtk_widget_set_size_request (button9k, 112, 48);

  alignment5 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_show (alignment5);
  gtk_container_add (GTK_CONTAINER (button9k), alignment5);

  hbox5 = gtk_hbox_new (FALSE, 2);
  gtk_widget_show (hbox5);
  gtk_container_add (GTK_CONTAINER (alignment5), hbox5);

  image6 = gtk_image_new_from_stock ("gtk-add", GTK_ICON_SIZE_BUTTON);
  gtk_widget_show (image6);
  gtk_box_pack_start (GTK_BOX (hbox5), image6, FALSE, FALSE, 0);

  label109 = gtk_label_new_with_mnemonic (_("Add"));
  gtk_widget_show (label109);
  gtk_box_pack_start (GTK_BOX (hbox5), label109, FALSE, FALSE, 0);

  button10k = gtk_button_new ();
  gtk_widget_show (button10k);
  gtk_fixed_put (GTK_FIXED (fixed2), button10k, 384, 200);
  gtk_widget_set_size_request (button10k, 112, 48);

  alignment6 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_show (alignment6);
  gtk_container_add (GTK_CONTAINER (button10k), alignment6);

  hbox6 = gtk_hbox_new (FALSE, 2);
  gtk_widget_show (hbox6);
  gtk_container_add (GTK_CONTAINER (alignment6), hbox6);

  image7 = gtk_image_new_from_stock ("gtk-find", GTK_ICON_SIZE_BUTTON);
  gtk_widget_show (image7);
  gtk_box_pack_start (GTK_BOX (hbox6), image7, FALSE, FALSE, 0);

  label110 = gtk_label_new_with_mnemonic (_("Show"));
  gtk_widget_show (label110);
  gtk_box_pack_start (GTK_BOX (hbox6), label110, FALSE, FALSE, 0);

  label2 = gtk_label_new (_("Schedule"));
  gtk_widget_show (label2);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook1), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook1), 1), label2);

  fixed3 = gtk_fixed_new ();
  gtk_widget_show (fixed3);
  gtk_container_add (GTK_CONTAINER (notebook1), fixed3);

  treeview1 = gtk_tree_view_new ();
  gtk_widget_show (treeview1);
  gtk_fixed_put (GTK_FIXED (fixed3), treeview1, 72, 144);
  gtk_widget_set_size_request (treeview1, 300, 200);

  label3 = gtk_label_new (_("Consulting medical files"));
  gtk_widget_show (label3);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook1), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook1), 2), label3);

  fixed4 = gtk_fixed_new ();
  gtk_widget_show (fixed4);
  gtk_container_add (GTK_CONTAINER (notebook1), fixed4);

  button6 = gtk_button_new ();
  gtk_widget_show (button6);
  gtk_fixed_put (GTK_FIXED (fixed4), button6, 56, 704);
  gtk_widget_set_size_request (button6, 176, 53);

  alignment7 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_show (alignment7);
  gtk_container_add (GTK_CONTAINER (button6), alignment7);

  hbox7 = gtk_hbox_new (FALSE, 2);
  gtk_widget_show (hbox7);
  gtk_container_add (GTK_CONTAINER (alignment7), hbox7);

  image8 = gtk_image_new_from_stock ("gtk-add", GTK_ICON_SIZE_BUTTON);
  gtk_widget_show (image8);
  gtk_box_pack_start (GTK_BOX (hbox7), image8, FALSE, FALSE, 0);

  label111 = gtk_label_new_with_mnemonic (_("Add"));
  gtk_widget_show (label111);
  gtk_box_pack_start (GTK_BOX (hbox7), label111, FALSE, FALSE, 0);

  button7 = gtk_button_new ();
  gtk_widget_show (button7);
  gtk_fixed_put (GTK_FIXED (fixed4), button7, 1272, 696);
  gtk_widget_set_size_request (button7, 170, 61);

  alignment8 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_show (alignment8);
  gtk_container_add (GTK_CONTAINER (button7), alignment8);

  hbox8 = gtk_hbox_new (FALSE, 2);
  gtk_widget_show (hbox8);
  gtk_container_add (GTK_CONTAINER (alignment8), hbox8);

  image9 = gtk_image_new_from_stock ("gtk-delete", GTK_ICON_SIZE_BUTTON);
  gtk_widget_show (image9);
  gtk_box_pack_start (GTK_BOX (hbox8), image9, FALSE, FALSE, 0);

  label112 = gtk_label_new_with_mnemonic (_("Delete"));
  gtk_widget_show (label112);
  gtk_box_pack_start (GTK_BOX (hbox8), label112, FALSE, FALSE, 0);

  label4 = gtk_label_new (_("Share exercices for members"));
  gtk_widget_show (label4);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook1), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook1), 3), label4);

  fixed5 = gtk_fixed_new ();
  gtk_widget_show (fixed5);
  gtk_container_add (GTK_CONTAINER (notebook1), fixed5);

  label17 = gtk_label_new (_("Opinion"));
  gtk_widget_show (label17);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook1), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook1), 4), label17);

  g_signal_connect ((gpointer) bt_editprofil, "clicked",
                    G_CALLBACK (on_bt_editprofil_clicked),
                    NULL);
  g_signal_connect ((gpointer) bt_disconnect, "clicked",
                    G_CALLBACK (on_bt_disconnect_clicked),
                    NULL);
  g_signal_connect ((gpointer) button9k, "clicked",
                    G_CALLBACK (on_button9k_clicked),
                    NULL);
  g_signal_connect ((gpointer) button10k, "clicked",
                    G_CALLBACK (on_button10k_clicked),
                    NULL);
  /*g_signal_connect ((gpointer) button6, "clicked",
                    G_CALLBACK (on_button6_clicked),
                    NULL);
  g_signal_connect ((gpointer) button7, "clicked",
                    G_CALLBACK (on_button7_clicked),
                    NULL);*/

  /* Store pointers to all widgets, for use by lookup_widget(). */
  GLADE_HOOKUP_OBJECT_NO_REF (window1, window1, "window1");
  GLADE_HOOKUP_OBJECT (window1, notebook1, "notebook1");
  GLADE_HOOKUP_OBJECT (window1, fixed1, "fixed1");
  GLADE_HOOKUP_OBJECT (window1, label7, "label7");
  GLADE_HOOKUP_OBJECT (window1, label11, "label11");
  GLADE_HOOKUP_OBJECT (window1, label18, "label18");
  GLADE_HOOKUP_OBJECT (window1, label12, "label12");
  GLADE_HOOKUP_OBJECT (window1, label8, "label8");
  GLADE_HOOKUP_OBJECT (window1, label15, "label15");
  GLADE_HOOKUP_OBJECT (window1, label28, "label28");
  GLADE_HOOKUP_OBJECT (window1, label13, "label13");
  GLADE_HOOKUP_OBJECT (window1, label16, "label16");
  GLADE_HOOKUP_OBJECT (window1, label9, "label9");
  GLADE_HOOKUP_OBJECT (window1, label10, "label10");
  GLADE_HOOKUP_OBJECT (window1, label5, "label5");
  GLADE_HOOKUP_OBJECT (window1, label6, "label6");
  GLADE_HOOKUP_OBJECT (window1, label99, "label99");
  GLADE_HOOKUP_OBJECT (window1, bt_editprofil, "bt_editprofil");
  GLADE_HOOKUP_OBJECT (window1, alignment3, "alignment3");
  GLADE_HOOKUP_OBJECT (window1, hbox3, "hbox3");
  GLADE_HOOKUP_OBJECT (window1, image4, "image4");
  GLADE_HOOKUP_OBJECT (window1, label107, "label107");
  GLADE_HOOKUP_OBJECT (window1, bt_disconnect, "bt_disconnect");
  GLADE_HOOKUP_OBJECT (window1, alignment4, "alignment4");
  GLADE_HOOKUP_OBJECT (window1, hbox4, "hbox4");
  GLADE_HOOKUP_OBJECT (window1, image5, "image5");
  GLADE_HOOKUP_OBJECT (window1, label108, "label108");
  GLADE_HOOKUP_OBJECT (window1, label_1, "label_1");
  GLADE_HOOKUP_OBJECT (window1, fixed2, "fixed2");
  GLADE_HOOKUP_OBJECT (window1, spinbutton1, "spinbutton1");
  GLADE_HOOKUP_OBJECT (window1, spinbutton2, "spinbutton2");
  GLADE_HOOKUP_OBJECT (window1, spinbutton3, "spinbutton3");
  GLADE_HOOKUP_OBJECT (window1, label100, "label100");
  GLADE_HOOKUP_OBJECT (window1, label101, "label101");
  GLADE_HOOKUP_OBJECT (window1, label102, "label102");
  GLADE_HOOKUP_OBJECT (window1, combobox1, "combobox1");
  GLADE_HOOKUP_OBJECT (window1, label103, "label103");
  GLADE_HOOKUP_OBJECT (window1, treeview2, "treeview2");
  GLADE_HOOKUP_OBJECT (window1, label104, "label104");
  GLADE_HOOKUP_OBJECT (window1, button9k, "button9k");
  GLADE_HOOKUP_OBJECT (window1, alignment5, "alignment5");
  GLADE_HOOKUP_OBJECT (window1, hbox5, "hbox5");
  GLADE_HOOKUP_OBJECT (window1, image6, "image6");
  GLADE_HOOKUP_OBJECT (window1, label109, "label109");
  GLADE_HOOKUP_OBJECT (window1, button10k, "button10k");
  GLADE_HOOKUP_OBJECT (window1, alignment6, "alignment6");
  GLADE_HOOKUP_OBJECT (window1, hbox6, "hbox6");
  GLADE_HOOKUP_OBJECT (window1, image7, "image7");
  GLADE_HOOKUP_OBJECT (window1, label110, "label110");
  GLADE_HOOKUP_OBJECT (window1, label2, "label2");
  GLADE_HOOKUP_OBJECT (window1, fixed3, "fixed3");
  GLADE_HOOKUP_OBJECT (window1, treeview1, "treeview1");
  GLADE_HOOKUP_OBJECT (window1, label3, "label3");
  GLADE_HOOKUP_OBJECT (window1, fixed4, "fixed4");
  GLADE_HOOKUP_OBJECT (window1, button6, "button6");
  GLADE_HOOKUP_OBJECT (window1, alignment7, "alignment7");
  GLADE_HOOKUP_OBJECT (window1, hbox7, "hbox7");
  GLADE_HOOKUP_OBJECT (window1, image8, "image8");
  GLADE_HOOKUP_OBJECT (window1, label111, "label111");
  GLADE_HOOKUP_OBJECT (window1, button7, "button7");
  GLADE_HOOKUP_OBJECT (window1, alignment8, "alignment8");
  GLADE_HOOKUP_OBJECT (window1, hbox8, "hbox8");
  GLADE_HOOKUP_OBJECT (window1, image9, "image9");
  GLADE_HOOKUP_OBJECT (window1, label112, "label112");
  GLADE_HOOKUP_OBJECT (window1, label4, "label4");
  GLADE_HOOKUP_OBJECT (window1, fixed5, "fixed5");
  GLADE_HOOKUP_OBJECT (window1, label17, "label17");

  return window1;
}

GtkWidget*
create_windoweditkine (void)
{
  GtkWidget *window2;
  GtkWidget *fixed6;
  GtkWidget *entry1;
  GtkWidget *entry2;
  GtkWidget *label19;
  GtkWidget *label20;
  GtkWidget *label21;
  GtkWidget *entry3;
  GtkWidget *entry6;
  GtkWidget *label23;
  GtkWidget *entry7;
  GtkWidget *label24;
  GtkWidget *entry8;
  GtkWidget *image1;
  GtkWidget *label27;
  GtkWidget *label22;
  GtkWidget *entry11;
  GtkWidget *button5k;
  GtkWidget *alignment2;
  GtkWidget *hbox2;
  GtkWidget *image3;
  GtkWidget *label106;

  window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window2), _("window2"));

  fixed6 = gtk_fixed_new ();
  gtk_widget_show (fixed6);
  gtk_container_add (GTK_CONTAINER (window2), fixed6);

  entry1 = gtk_entry_new ();
  gtk_widget_show (entry1);
  gtk_fixed_put (GTK_FIXED (fixed6), entry1, 152, 256);
  gtk_widget_set_size_request (entry1, 200, 40);
  gtk_entry_set_invisible_char (GTK_ENTRY (entry1), 8226);

  entry2 = gtk_entry_new ();
  gtk_widget_show (entry2);
  gtk_fixed_put (GTK_FIXED (fixed6), entry2, 152, 344);
  gtk_widget_set_size_request (entry2, 200, 43);
  gtk_entry_set_invisible_char (GTK_ENTRY (entry2), 8226);

  label19 = gtk_label_new (_("First name :"));
  gtk_widget_show (label19);
  gtk_fixed_put (GTK_FIXED (fixed6), label19, 24, 256);
  gtk_widget_set_size_request (label19, 104, 32);

  label20 = gtk_label_new (_("Name :"));
  gtk_widget_show (label20);
  gtk_fixed_put (GTK_FIXED (fixed6), label20, 16, 352);
  gtk_widget_set_size_request (label20, 104, 32);

  label21 = gtk_label_new (_("Date of birth :"));
  gtk_widget_show (label21);
  gtk_fixed_put (GTK_FIXED (fixed6), label21, 32, 440);
  gtk_widget_set_size_request (label21, 96, 32);

  entry3 = gtk_entry_new ();
  gtk_widget_show (entry3);
  gtk_fixed_put (GTK_FIXED (fixed6), entry3, 152, 432);
  gtk_widget_set_size_request (entry3, 240, 43);
  gtk_entry_set_invisible_char (GTK_ENTRY (entry3), 8226);

  entry6 = gtk_entry_new ();
  gtk_widget_show (entry6);
  gtk_fixed_put (GTK_FIXED (fixed6), entry6, 152, 504);
  gtk_widget_set_size_request (entry6, 184, 40);
  gtk_entry_set_invisible_char (GTK_ENTRY (entry6), 8226);

  label23 = gtk_label_new (_("Adresse :"));
  gtk_widget_show (label23);
  gtk_fixed_put (GTK_FIXED (fixed6), label23, 32, 608);
  gtk_widget_set_size_request (label23, 81, 40);

  entry7 = gtk_entry_new ();
  gtk_widget_show (entry7);
  gtk_fixed_put (GTK_FIXED (fixed6), entry7, 152, 616);
  gtk_widget_set_size_request (entry7, 264, 32);
  gtk_entry_set_invisible_char (GTK_ENTRY (entry7), 8226);

  label24 = gtk_label_new (_("Bio :"));
  gtk_widget_show (label24);
  gtk_fixed_put (GTK_FIXED (fixed6), label24, 40, 696);
  gtk_widget_set_size_request (label24, 49, 17);

  entry8 = gtk_entry_new ();
  gtk_widget_show (entry8);
  gtk_fixed_put (GTK_FIXED (fixed6), entry8, 136, 680);
  gtk_widget_set_size_request (entry8, 616, 168);
  gtk_entry_set_invisible_char (GTK_ENTRY (entry8), 8226);

  image1 = create_pixmap (window2, NULL);
  gtk_widget_show (image1);
  gtk_fixed_put (GTK_FIXED (fixed6), image1, 144, 16);
  gtk_widget_set_size_request (image1, 208, 152);

  label27 = gtk_label_new (_("Email :"));
  gtk_widget_show (label27);
  gtk_fixed_put (GTK_FIXED (fixed6), label27, 32, 568);
  gtk_widget_set_size_request (label27, 64, 32);

  label22 = gtk_label_new (_("Phone number :"));
  gtk_widget_show (label22);
  gtk_fixed_put (GTK_FIXED (fixed6), label22, 24, 504);
  gtk_widget_set_size_request (label22, 120, 48);

  entry11 = gtk_entry_new ();
  gtk_widget_show (entry11);
  gtk_fixed_put (GTK_FIXED (fixed6), entry11, 152, 568);
  gtk_widget_set_size_request (entry11, 344, 32);
  gtk_entry_set_invisible_char (GTK_ENTRY (entry11), 8226);

  button5k = gtk_button_new ();
  gtk_widget_show (button5k);
  gtk_fixed_put (GTK_FIXED (fixed6), button5k, 1400, 776);
  gtk_widget_set_size_request (button5k, 154, 56);

  alignment2 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_show (alignment2);
  gtk_container_add (GTK_CONTAINER (button5k), alignment2);

  hbox2 = gtk_hbox_new (FALSE, 2);
  gtk_widget_show (hbox2);
  gtk_container_add (GTK_CONTAINER (alignment2), hbox2);

  image3 = gtk_image_new_from_stock ("gtk-apply", GTK_ICON_SIZE_BUTTON);
  gtk_widget_show (image3);
  gtk_box_pack_start (GTK_BOX (hbox2), image3, FALSE, FALSE, 0);

  label106 = gtk_label_new_with_mnemonic (_("Save"));
  gtk_widget_show (label106);
  gtk_box_pack_start (GTK_BOX (hbox2), label106, FALSE, FALSE, 0);

  g_signal_connect ((gpointer) button5k, "clicked",
                    G_CALLBACK (on_button5k_clicked),
                    NULL);

  /* Store pointers to all widgets, for use by lookup_widget(). */
  GLADE_HOOKUP_OBJECT_NO_REF (window2, window2, "window2");
  GLADE_HOOKUP_OBJECT (window2, fixed6, "fixed6");
  GLADE_HOOKUP_OBJECT (window2, entry1, "entry1");
  GLADE_HOOKUP_OBJECT (window2, entry2, "entry2");
  GLADE_HOOKUP_OBJECT (window2, label19, "label19");
  GLADE_HOOKUP_OBJECT (window2, label20, "label20");
  GLADE_HOOKUP_OBJECT (window2, label21, "label21");
  GLADE_HOOKUP_OBJECT (window2, entry3, "entry3");
  GLADE_HOOKUP_OBJECT (window2, entry6, "entry6");
  GLADE_HOOKUP_OBJECT (window2, label23, "label23");
  GLADE_HOOKUP_OBJECT (window2, entry7, "entry7");
  GLADE_HOOKUP_OBJECT (window2, label24, "label24");
  GLADE_HOOKUP_OBJECT (window2, entry8, "entry8");
  GLADE_HOOKUP_OBJECT (window2, image1, "image1");
  GLADE_HOOKUP_OBJECT (window2, label27, "label27");
  GLADE_HOOKUP_OBJECT (window2, label22, "label22");
  GLADE_HOOKUP_OBJECT (window2, entry11, "entry11");
  GLADE_HOOKUP_OBJECT (window2, button5k, "button5k");
  GLADE_HOOKUP_OBJECT (window2, alignment2, "alignment2");
  GLADE_HOOKUP_OBJECT (window2, hbox2, "hbox2");
  GLADE_HOOKUP_OBJECT (window2, image3, "image3");
  GLADE_HOOKUP_OBJECT (window2, label106, "label106");

  return window2;
}

/*void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}*/


/*void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}*/


/*void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}*/


void
on_button5k_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	Kine kine;
	GtkWidget *input1, *input2,*input3,*input4,*input5,*input6,*input7;
        GtkWidget *window1;
        //window1=lookup_widget(objet,"acceuil");
	input1=lookup_widget(objet,"entry1");
	input2=lookup_widget(objet,"entry2");
	input3=lookup_widget(objet,"entry3");
	input4=lookup_widget(objet,"entry6");
	input5=lookup_widget(objet,"entry7");
	input6=lookup_widget(objet,"entry8");
	input7=lookup_widget(objet,"entry11");
	strcpy(kine.firstname,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(kine.name,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(kine.daate_birth,gtk_entry_get_text(GTK_ENTRY(input3)));
	strcpy(kine.phoneNumber,gtk_entry_get_text(GTK_ENTRY(input4)));
	strcpy(kine.adresse,gtk_entry_get_text(GTK_ENTRY(input5)));
	strcpy(kine.bio,gtk_entry_get_text(GTK_ENTRY(input6)));
	strcpy(kine.Email,gtk_entry_get_text(GTK_ENTRY(input7)));

	Edit_kine(kine);

	 kine=Get_kine();
	/*GtkWidget *output;
	output=lookup_widget(objet,"label6");*/
	//gtk_label_set_text(GTK_LABEL(output),"qsd");

	GtkWidget  *fenetre_afficher;

	fenetre_afficher=lookup_widget(objet,"window2");
	gtk_widget_hide(fenetre_afficher);

	window1 = create_windowkine();
	gtk_widget_show (window1);
        affich_kine(window1);
}




void
on_button9k_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
 	GtkWidget *combobox;
	GtkWidget *day;
	GtkWidget *month;
	GtkWidget *year;
	GtkWidget *output;
	int error=0;
	char sort[50];
	int r;
	reservationn s;
	output=lookup_widget(button,"label104");
	combobox=lookup_widget(button,"combobox1");
	day=lookup_widget(button,"spinbutton1");
	month=lookup_widget(button,"spinbutton2");
	year=lookup_widget(button,"spinbutton3");

	gtk_label_set_text(GTK_LABEL(output), "");

	s.dt.day=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (day));
	s.dt.month=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (month));
	s.dt.year=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (year));

	if(strcmp("10h ==>12h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)		
		s.h=1;
	else if(strcmp("16h ==>18h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)	
		s.h=2;
	/*else
	{
		error=1;
		strcpy(sort,"please chose hour");
	}*/
	
//if(error==0)
{
	r=verif_resk(s);
	
	if(r==1)
		{
                
		strcpy(sort," already reserved");
		
		}
	else
		{
		strcpy(sort,"reserved date");
		reserverk_date(s);
		
		}
}
	/*if(strcmp("de 16h==>18h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)		
		s.h=1;
	else  
		s.h=2;
	
	r=verif_res(s);
	
	if(r==1)
		{
		
		strcpy(sort,"reserved date");
		}
	else
		{
                 reserver_date(s);
		strcpy(sort," already reserved");
		
		}*/



gtk_label_set_text(GTK_LABEL(output), sort);
}


void
on_button10k_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *label2;
GtkWidget *treeview2;



label2=lookup_widget(button,"label2");

      

treeview2=lookup_widget(label2,"treeview2");

afficher_calendar(treeview2);
}


/*void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}*/


void
on_bt_editprofil_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *window1;
window1=lookup_widget(button,"window1");
gtk_widget_hide(window1);
fenetre_ajout=create_windoweditkine();
gtk_widget_show(fenetre_ajout);
gtk_widget_hide(window1);
affiche_kine(fenetre_ajout);

}


void
on_bt_disconnect_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
	window1=lookup_widget(button,"window1");	
	gtk_widget_hide(window1);
	GtkWidget *window3;
	window3= create_window2();
	gtk_widget_show (window3);
}

/*int verifier (char login[], char password[]){
FILE *f;
char loginn[20];char password1[20];


f=fopen("users.txt","r");
if(f !=NULL) 
{
     while(fscanf(f,"%s %s \n",loginn,password1)!=EOF)
{ 
          if (strcmp(login, loginn) == 0 )
{
          if( strcmp(password, password1) == 0 )
{
               
  }
  } 
  }
  }
fclose(f);
return k;
}*/
enum   
{       
        DAY,
        MONTH,
	YEAR,
        HOUR,
        COLUMNS
};

void afficher_calendar(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char day [30];
	char month [30];
	char year [30];
	char hour [30];
        

       FILE *f;
	
	store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" day", renderer, "text",DAY, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" month", renderer, "text",MONTH, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  year", renderer, "text",YEAR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  hour", renderer, "text",HOUR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		

               
	
	}

	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f = fopen("date_reserver.txt", "r");
	
	if(f==NULL)
	{

		return;
	}		
	else 
	{ f = fopen("date_reserver.txt", "a+");
              while(fscanf(f,"%s %s %s %s \n",day,month,year,hour)!=EOF)
		{
			gtk_list_store_append (store, &iter);
			if(strcmp(hour,"1")==0)
				gtk_list_store_set (store, &iter, DAY, day, MONTH, month, YEAR, year, HOUR, "10h ==>12h", -1);
			if(strcmp(hour,"2")==0)
				gtk_list_store_set (store, &iter, DAY, day, MONTH, month, YEAR, year, HOUR, "16h ==>18h", -1);
		}
		fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}
}




void Edit_kine(Kine kine)
{

 FILE *f;
  f=fopen("kine.txt","w");
  if(f!=NULL)
  {
	  fprintf(f,"%s %s %s %s %s %s %s\n",kine.firstname,kine.name,kine.daate_birth,kine.phoneNumber,kine.Email,kine.adresse,kine.bio);

	  fclose(f);
   }
}
Kine Get_kine()
{
	Kine kine;
	 FILE *f;
	 f = fopen("kine.txt", "r");
	fscanf(f,"%s %s %s %s %s %s %s\n",kine.firstname,kine.name,kine.daate_birth,kine.phoneNumber,kine.Email,kine.adresse,kine.bio);

	return kine;
}
void affich_kine(GtkWidget *window)
{
FILE *f;
GtkWidget *output;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
Kine k;

output=lookup_widget(window,"label6");
output1=lookup_widget(window,"label8");
output2=lookup_widget(window,"label99");
output3=lookup_widget(window,"label10");
output4=lookup_widget(window,"label12");
output5=lookup_widget(window,"label28");
output6=lookup_widget(window,"label16");
f=fopen("kine.txt","r");
if (f!=NULL)
 {
	while (fscanf(f,"%s %s %s %s %s %s %s\n",k.firstname,k.name,k.daate_birth,k.phoneNumber,k.Email,k.adresse,k.bio)!=EOF)
		{gtk_label_set_text(GTK_LABEL(output),k.firstname);
		gtk_label_set_text(GTK_LABEL(output1),k.name);
		gtk_label_set_text(GTK_LABEL(output2),k.daate_birth);
		gtk_label_set_text(GTK_LABEL(output3),k.phoneNumber);
		gtk_label_set_text(GTK_LABEL(output4),k.Email);
		gtk_label_set_text(GTK_LABEL(output5),k.adresse);
		gtk_label_set_text(GTK_LABEL(output6),k.bio);}
}
}
void affiche_kine(GtkWidget *window)
{
FILE *f;
GtkWidget *output;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
Kine k;

output=lookup_widget(window,"entry1");
output1=lookup_widget(window,"entry2");
output2=lookup_widget(window,"entry3");
output3=lookup_widget(window,"entry6");
output4=lookup_widget(window,"entry11");
output5=lookup_widget(window,"entry7");
output6=lookup_widget(window,"entry8");
f=fopen("kine.txt","r");
if (f!=NULL)
 {
	while (fscanf(f,"%s %s %s %s %s %s %s\n",k.firstname,k.name,k.daate_birth,k.phoneNumber,k.Email,k.adresse,k.bio)!=EOF)
		{gtk_entry_set_text(GTK_ENTRY(output),k.firstname);
		gtk_entry_set_text(GTK_ENTRY(output1),k.name);
		gtk_entry_set_text(GTK_ENTRY(output2),k.daate_birth);
		gtk_entry_set_text(GTK_ENTRY(output3),k.phoneNumber);
		gtk_entry_set_text(GTK_ENTRY(output4),k.Email);
		gtk_entry_set_text(GTK_ENTRY(output5),k.adresse);
		gtk_entry_set_text(GTK_ENTRY(output6),k.bio);}
}
}

int verif_resk(reservationn s)
{
int v=0; 
reservationn res;
FILE*f;
f=fopen("date_reserver.txt","r");
if(f!=NULL)
{
	while(!v && fscanf(f,"%d %d %d %d",&res.dt.day,&res.dt.month,&res.dt.year,&res.h)!=EOF)
	{


			if ((res.dt.day==s.dt.day) && (res.dt.month==s.dt.month) && (res.dt.year==s.dt.year) && (res.h==s.h))
					{
						v=1;
					}	
	}

}

fclose(f);
	
return v;
}
void reserverk_date(reservationn s)
{
	FILE*f;
	f=fopen("date_reserver.txt","a+");


	if(f!=NULL)
	{
	fprintf(f,"%d %d %d %d\n",s.dt.day,s.dt.month,s.dt.year,s.h);
	fclose(f);
	}
}





