#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

/*void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

/*void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);*/

void
on_disconnect_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_edit_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_adduser_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_deluser_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_save1_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_save2_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_gal1_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_gal3_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_gal2_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_gal4_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_gal5_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_gal6_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_doctors_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_coach_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_client_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_all_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_dietitian_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_physio_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_importprof_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_confirmedit_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_anuledit_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_connect_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_back1_clicked                       (GtkButton       *button,
                                        gpointer         user_data);
