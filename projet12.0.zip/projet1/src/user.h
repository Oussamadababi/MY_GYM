#include <gtk/gtk.h>
typedef struct
{
char id[50];
char username[20];
char password[30];
char func[20];
}user;
void add_user(user p,GtkWidget *output,GtkWidget *input1,GtkWidget *input2);
void delete_user(user p,GtkWidget *output);
void show_user(GtkWidget *list);
void setbufer(GtkWidget *text_view);
void show_user_as(GtkWidget *list,char ch[20]);
void importfile(GtkWidget *window3,GtkWidget *output,GtkWidget *output1);
void showadmin(GtkWidget *output1,GtkWidget *output2,GtkWidget *output3,GtkWidget *output4,GtkWidget *output5,GtkWidget *output6,GtkWidget *output7,char ch[100]);
void showadmin1(GtkWidget *output1,GtkWidget *output2,GtkWidget *output3,GtkWidget *output4,GtkWidget *output5,GtkWidget *output6,GtkWidget *input1,GtkWidget *input2,GtkWidget *input3,GtkWidget *input4,char ch[100]);
void modifdata(char ch[20],char name1[20],char fname1[20],char phone1[20],char mail1[30],char path1[100] );
//void afficher_mygym(GtkWidget *window4);
//void afficher_personne(GtkWidget *liste);

