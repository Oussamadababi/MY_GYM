#include <gtk/gtk.h>


void
on_button1Med_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button3Med_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button4Med_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button8Med_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button6Med_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button5Med_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button7Med_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button13Med_clicked                    (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button12Med_clicked                    (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button14Med_clicked                    (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button15Med_clicked                    (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button16Med_clicked                    (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button17Med_clicked                    (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button18Med_clicked                    (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button19Med_clicked                    (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button20Med_clicked                    (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button21Med_clicked                    (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button9Med_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button22Med_clicked                    (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button2Med_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button23Med_clicked                    (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button26Med_clicked                    (GtkButton       *object_graphique,
                                        gpointer         user_data);

void
on_button24Med_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button25Med_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
GtkWidget* create_NutritionistSpace (void);
GtkWidget* create_AddAppointment (void);
GtkWidget* create_AddMedFile (void);
GtkWidget* create_Medfiles (void);
GtkWidget* create_Menfiles (void);
GtkWidget* create_Womenfiles (void);
GtkWidget* create_DeleteMedFile (void);
GtkWidget* create_Appointments (void);
GtkWidget* create_EditMedFile (void);
typedef struct{
char name[20];
char lastName[20];
char birthDate[20];
char adress[20];
char CIN[20];
char gender;
char bloodGroup;
char disease[20];
char allergyReaction[20];
char treatment[100];}medicalfile;

void add_file(medicalfile mf);
typedef struct{
char day[20];
char month[20];
char year[20];
char hour[20];}displayapp;

void display_app(GtkWidget *liste);
typedef struct{
char name[20];
char lastname[20];
char birthdate[20];
char adress[20];
char cin[20];
char gender;
char bloodgroup;
char disease[20];
char allergyreaction[20];
char treatment[100];}displayfile;

void display_file(GtkWidget *liste,char[20]);
typedef struct{
int day;
int month;
int year;
char hour[20];
}DateMed;

void add_appoint(DateMed d,char ch[20],GtkWidget *output);

typedef struct
{
DateMed d;
int hour;
}checkappoint;

int verify_check(checkappoint ap);
void check (checkappoint c);


