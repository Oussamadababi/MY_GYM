#include <stdio.h>
#include <stdlib.h>
#include "user.h"
#include <gtk/gtk.h>
#include <string.h>
#include "interface.h"
#include "callbacks.h"
enum
{
  USER,
  ID,
  PASS,
  FUNC,
  //SELECTION,
  COLUMNS
};
/**************************************** ADD USER ***********************/
void add_user(user p,GtkWidget *output,GtkWidget *input1,GtkWidget *input2)
{
	FILE *f;
	char user[20],pass[20],fun[20],id[50];
	int i=0;
	f=fopen("users.txt","a+");
	if(f!=NULL)
		
	{	
		while (fscanf(f,"%s %s %s %s",id,user,pass,fun)!=EOF && ((strcmp(p.username,user)!=0 && (strcmp(p.func,pass)!=0))))
			{
				
	
				i++;

			}
		if (strcmp(p.username,user)==0 && (strcmp(p.func,fun)==0))
					{gtk_label_set_text(GTK_LABEL(output),"user is already signed !!!");
					gtk_entry_set_text(GTK_ENTRY(input1),"");
					gtk_entry_set_text(GTK_ENTRY(input2),"");
					}

		 else
			{
			snprintf(p.id, 10, "%d", i);
                        fprintf(f,"%s %s %s %s\n",p.id,p.username,p.password,p.func);
			gtk_label_set_text(GTK_LABEL(output),"user succefuly added !!!");
			}
		fclose(f);
	}
}
/***************************** show treeview without filter ************/
void show_user(GtkWidget *list)
{
	GtkCellRenderer *rend;
	GtkTreeViewColumn *col;
	GtkTreeIter iter;
	GtkTreeStore *store;
	char username[30];
	char password[20];
	char func[20];
	char id[50];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model(list);
	if (store==NULL)
	{
		
		rend= gtk_cell_renderer_text_new();
		col=gtk_tree_view_column_new_with_attributes(" ID",rend,"text",ID,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (list),col);
		
		
		rend= gtk_cell_renderer_text_new();
		col=gtk_tree_view_column_new_with_attributes(" usernames",rend,"text",USER,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (list),col);

		rend= gtk_cell_renderer_text_new();
		col=gtk_tree_view_column_new_with_attributes(" passwords",rend,"text",PASS,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (list),col);

		rend= gtk_cell_renderer_text_new();
		col=gtk_tree_view_column_new_with_attributes(" functions",rend,"text",FUNC,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (list),col);
	}
	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("users.txt","r");
	if (f!=NULL)
	{
		
		while(fscanf(f,"%s %s %s %s \n",id,username,password,func)!=EOF)
		{	
			gtk_list_store_append (store,&iter);
			gtk_list_store_set (store,&iter,ID,id,USER,username,PASS,password,FUNC,func,-1);
		}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(list),GTK_TREE_MODEL(store));
	g_object_unref (store);
	}
}
/****************** DELETE USER ***************************/
void delete_user(user p,GtkWidget *output) 
{
    FILE *f1, *f2;
    char user[20],pass[20],fun[20],id[50];
    f1 = fopen("users.txt", "r");
    f2 = fopen("replica.txt", "w");
    int i=0;
    char ch[50];
    while (fscanf(f1,"%s %s %s %s",id,user,pass,fun)!=EOF)
    {
        //i++;
	
        if ((strcmp(p.username,user)!=0) || (strcmp(p.func,fun)!=0))
            
            {   
		i++;
		snprintf(ch, 10, "%d", i-1);
                fprintf(f2,"%s %s %s %s\n",ch,user,pass,fun);
            }
    }
    fclose(f1);
    fclose(f2);
    remove("users.txt");
    rename("replica.txt", "users.txt");
    gtk_label_set_text(GTK_LABEL(output),"user succefuly deleted !!!");
}
/*void afficher_mygym(GtkWidget *window4)
{
GtkWidget *output1,*output2,*output3,*output4;
FILE*f;
char ch1[400],ch2[400],ch3[400],ch4[400],ch11[10000]={0},ch22[10000]={0},ch33[10000]={0},ch44[10000]={0};




output1=lookup_widget(window4,"label30");
f=fopen("creation.txt","r");
if(f!=NULL){
while (fgets(ch1,400,f)!=NULL)//(f,"%s",ch1)!=EOF)
{strcat(ch11,ch1);
strcat(ch11,"\n");
}
fclose(f);
gtk_label_set_text(GTK_LABEL(output1),ch11);}

output2=lookup_widget(window4,"label32");
f=fopen("ad.txt","r");
if(f!=NULL){
while (fgets(ch2,400,f)!=NULL)//(f,"%s",ch1)!=EOF)
{strcat(ch22,ch2);
strcat(ch22,"\n");
}
fclose(f);
gtk_label_set_text(GTK_LABEL(output2),ch22);}
output3=lookup_widget(window4,"label34");
f=fopen("location.txt","r");
if(f!=NULL){
while (fgets(ch3,400,f)!=NULL)//(f,"%s",ch1)!=EOF)
{strcat(ch33,ch3);
strcat(ch33,"\n");
}
fclose(f);
gtk_label_set_text(GTK_LABEL(output3),ch33);}
output4=lookup_widget(window4,"label36");
f=fopen("natiotrop.txt","r");
if(f!=NULL){
while (fgets(ch4,400,f)!=NULL)//(f,"%s",ch1)!=EOF)
{strcat(ch44,ch4);
strcat(ch44,"\n");}
fclose(f);
gtk_label_set_text(GTK_LABEL(output4),ch44);}

}*/
/********************************** MODIFICATION DE PHOTO ***************************/
void importfile(GtkWidget *window3,GtkWidget *output,GtkWidget *output1)
{
GtkWidget *dialog;

char *filename;
dialog = gtk_file_chooser_dialog_new ("openfile",
                                      window3,
                                      GTK_FILE_CHOOSER_ACTION_OPEN,
                                      GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                                      GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
                                      NULL);

if (gtk_dialog_run (GTK_DIALOG (dialog)) == GTK_RESPONSE_ACCEPT)
  {
    

    filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
    
  

gtk_widget_destroy (dialog);
gtk_label_set_text(GTK_LABEL(output1),filename);

}
gtk_image_set_from_file (output,filename);
}


/*void setbufer(GtkWidget *text_view)
{
GtkTextBuffer *buffer;
char ch1[400];
char ch11[400];
FILE* f;
f=fopen("creation.txt","r");
if(f!=NULL){
while (fgets(ch1,400,f)!=NULL)
{strcat(ch11,ch1);
strcat(ch11,"\n");
}
fclose(f);
gtk_text_buffer_set_text (buffer,ch11,400);
gtk_text_view_set_buffer (text_view,buffer);
}
}*/
/******************** filtrage de treeview ************************/
void show_user_as(GtkWidget *list,char ch[20])
{
	GtkCellRenderer *rend;
	GtkTreeViewColumn *col;
	GtkTreeIter iter;
	GtkTreeStore *store;
	char username[30];
	char password[20];
	char func[20];
	char id[50];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model(list);
	if (store==NULL)
	{
		
		rend= gtk_cell_renderer_text_new();
		col=gtk_tree_view_column_new_with_attributes(" ID",rend,"text",ID,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (list),col);
		
		
		rend= gtk_cell_renderer_text_new();
		col=gtk_tree_view_column_new_with_attributes(" usernames",rend,"text",USER,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (list),col);

		rend= gtk_cell_renderer_text_new();
		col=gtk_tree_view_column_new_with_attributes(" passwords",rend,"text",PASS,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (list),col);

		rend= gtk_cell_renderer_text_new();
		col=gtk_tree_view_column_new_with_attributes(" functions",rend,"text",FUNC,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (list),col);
	}
	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("users.txt","r");
	if (f!=NULL)
	{
		
		while(fscanf(f,"%s %s %s %s \n",id,username,password,func)!=EOF)
		{	if (strcmp(func,ch)==0)
				{gtk_list_store_append (store,&iter);
				gtk_list_store_set (store,&iter,ID,id,USER,username,PASS,password,FUNC,func,-1);}
		}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(list),GTK_TREE_MODEL(store));
	g_object_unref (store);
	}
}
/************************* show admin profile *************************/
void showadmin(GtkWidget *output1,GtkWidget *output2,GtkWidget *output3,GtkWidget *output4,GtkWidget *output5,GtkWidget *output6,GtkWidget *output7,char ch[100])
{
	
	
	char user[20],user1[20],pass[20],fun[20],id[50],name[20],fname[20],phone[20],mail[20],path[100];
	
        FILE *f1;
	
	f1=fopen("users.txt","r");
	if (f1!=NULL)
	{
		while (fscanf(f1,"%s %s %s %s \n",id,user,pass,fun)!=EOF)
		{
			if (strcmp(ch,user)==0)
			{gtk_label_set_text(GTK_LABEL(output1),user);
			 gtk_label_set_text(GTK_LABEL(output2),fun);}
		}
	fclose(f1);
	}
	
	FILE *f2;
	f2=fopen("userdata.txt","r");
	if (f2!=NULL)
	{
		while(fscanf(f2,"%s %s %s %s %s %s",user1,name,fname,phone,mail,path)!=EOF)
		{
			if (strcmp(ch,user1)==0)
			{gtk_label_set_text(GTK_LABEL(output3),name);
			 gtk_label_set_text(GTK_LABEL(output4),fname);
			 gtk_label_set_text(GTK_LABEL(output5),phone);
			 gtk_label_set_text(GTK_LABEL(output6),mail);
			//gtk_label_set_text(GTK_LABEL(output8),path);	
			 gtk_image_set_from_file (output7,path);}
		}
	fclose(f2);
	}
}

/************************** reglage de page edit *********************************/
void showadmin1(GtkWidget *output1,GtkWidget *output2,GtkWidget *output3,GtkWidget *output4,GtkWidget *output5,GtkWidget *output6,GtkWidget *input1,GtkWidget *input2,GtkWidget *input3,GtkWidget *input4,char ch[100])
{
char user[20],user1[20],pass[20],fun[20],id[50],name[20],fname[20],phone[20],mail[20],path[100];
	
        FILE *f1;
	
	f1=fopen("users.txt","r");
	if (f1!=NULL)
	{
		while (fscanf(f1,"%s %s %s %s \n",id,user,pass,fun)!=EOF)
		{
			if (strcmp(ch,user)==0)
			{gtk_label_set_text(GTK_LABEL(output1),fun);
			 gtk_label_set_text(GTK_LABEL(output2),id);
			 gtk_label_set_text(GTK_LABEL(output3),user);
			gtk_label_set_text(GTK_LABEL(output6),path);
			gtk_label_set_text(GTK_LABEL(output4),pass);}
		}
	fclose(f1);
	}
	
	FILE *f2;
	f2=fopen("userdata.txt","r");
	if (f2!=NULL)
	{
		while(fscanf(f2,"%s %s %s %s %s %s",user1,name,fname,phone,mail,path)!=EOF)
		{
			if (strcmp(ch,user1)==0)
			{gtk_entry_set_text(GTK_ENTRY(input1),name);
			 gtk_entry_set_text(GTK_ENTRY(input2),fname);
			 gtk_entry_set_text(GTK_ENTRY(input3),phone);
			 gtk_entry_set_text(GTK_ENTRY(input4),mail);
			 gtk_image_set_from_file (output5,path);}
		}
	fclose(f2);
	}
}
/******************************* edit profile data ********************/
void modifdata(char ch[20],char name1[20],char fname1[20],char phone1[20],char mail1[30],char path1[100] )
{
char user1[20],name[20],fname[20],phone[20],mail[330],path[100];
FILE *f;
FILE *f1;
int i=0;
f=fopen("userdata.txt","a+");
f1=fopen("rep.txt","a+");

		while(fscanf(f,"%s %s %s %s %s %s",user1,name,fname,phone,mail,path)!=EOF && strcmp(ch,user1)!=0)
		{
			i++;
		}
		if (strcmp(ch,user1)==0)
			{	
				
				
				while(fscanf(f,"%s %s %s %s %s %s",user1,name,fname,phone,mail,path)!=EOF)
    				{
					if ((strcmp(ch,user1)!=0))
       			
                				{fprintf(f1,"%s %s %s %s %s %s\n",user1,name,fname,phone,mail,path);}
            			
						  
				}
				fprintf(f1,"%s %s %s %s %s %s\n",ch,name1,fname1,phone1,mail1,path1);
				
					
			fclose(f);
    			fclose(f1);
   			remove("userdata.txt");
    			rename("rep.txt", "userdata.txt");	
    				
			}
		else
		{ 	
			fprintf(f,"%s %s %s %s %s %s\n",ch,name1,fname1,phone1,mail1,path1);
			fclose(f);

		}
		
		
}

/*********************** import file ********************/


void on_importprof_clicked(GtkButton *button,  gpointer user_data)
{
GtkWidget *dialog;
GtkWidget *window4;
window4=lookup_widget(button,"window4");
GtkWidget *output, *output1;
output=lookup_widget(button,"image15");
output1=lookup_widget(button,"path");
char *ch1;

importfile(window4,output,output1);

}














