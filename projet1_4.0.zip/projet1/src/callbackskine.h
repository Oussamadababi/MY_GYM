#include <gtk/gtk.h>
GtkWidget* create_windowkine (void);
GtkWidget* create_windoweditkine (void);
/*void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);*/

/*void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data);*/

void
on_button5k_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9k_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button10k_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

/*void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);*/

void
on_bt_editprofil_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_bt_disconnect_clicked               (GtkButton       *button,
                                        gpointer         user_data);
//int verif (char login[], char password[]);
void afficher_calendar(GtkWidget *liste);

typedef struct
{
	
	char firstname[20];
	char name[20];
	char daate_birth[30];
	char phoneNumber[10];
	char adresse[40];
	char bio[1024];
	char Email[50];
}Kine;


void Edit_kine(Kine kine);
Kine Get_kine();
void affich_kine(GtkWidget *window);

typedef struct
{
int day;
int month;
int year;
}daate;
typedef struct
{
daate dt;
int h;
}reservationn;
int verif_resk(reservationn s);
void reserverk_date(reservationn s);

