#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include "user.h"
#include "callbacks1.h"
#include "callbackskine.h"
#include "interfaceadh.h"
#include "intermed.h"


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{


}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
window1=lookup_widget(button,"window1");
gtk_widget_hide(window1);
GtkWidget *window2;
window2 = create_window2 ();
gtk_widget_show (window2);


}


/*void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2,*output;
GtkWidget *window2;
window2=lookup_widget(button,"window2");
int tst=0;
FILE*f;
char username[100],password[100],user[30],pass[30],fun[20],id[5];
input1=lookup_widget(button,"entry1");
input2=lookup_widget(button,"entry2");
output=lookup_widget(button,"msger");
strcpy(username,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2)));
f=fopen("users.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %s %s %s",id,user,pass,fun)!=EOF)
	{
		if(strcmp(username,user)==0 && strcmp(password,pass)==0)
		{
			if (strcmp(fun,"admin") == 0) 

				{
					gtk_widget_hide(window2);
					GtkWidget *window3;
					window3= create_window3 ();
					gtk_widget_show (window3);
					GtkWidget *treeview1;
					GtkWidget *output1;
					GtkWidget *output2;
					GtkWidget *output3;
					GtkWidget *output4;
					GtkWidget *output5;
					GtkWidget *output6;
					GtkWidget *output7;	
					/*GtkWidget *output8;
					output2=lookup_widget(window3,"label57");*/
					/*output1=lookup_widget(window3,"ID");
					output2=lookup_widget(window3,"label57");
					output3=lookup_widget(window3,"name");
					output4=lookup_widget(window3,"Fname");
					output5=lookup_widget(window3,"phone");
					output6=lookup_widget(window3,"mail");
					output7=lookup_widget(window3,"image12");
					showadmin(output1,output2,output3,output4,output5,output6,output7,username);
					treeview1=lookup_widget(window3,"treeview1");
					show_user(treeview1);
					
					
				}
			        if (strcmp(fun,"Coach") == 0) 

				{	
					gtk_widget_hide(window2);
					GtkWidget *window3;
					window3=create_windowcoach (username);
					gtk_widget_show (window3);
					//GtkWidget *window3;
					//window3= create_window3 ();
					//gtk_widget_show (window3);
					//GtkWidget *treeview2;
					//treeview2=lookup_widget(window3,"treeview2");
					//show_user(treeview2);
				}
			/*block reservé pour les autres utilisateurs
			if (strcmp(fun,"") == 0) 

				{
					gtk_widget_hide(window2);
					GtkWidget *windowXX;
					window= create_windowXX ();
					gtk_widget_show (windowXX);
				}*/
		/*}
		else
			{
				gtk_label_set_text(GTK_LABEL(output),"nom d'utilisateur ou mot de passe incorrect");
				gtk_entry_set_text(GTK_ENTRY(input2),"");
				gtk_entry_set_text(GTK_ENTRY(input1),"");
			}
	}

	fclose(f);
	}

}/*





void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}*/


void
on_disconnect_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window3;

window3=lookup_widget(button,"window3");

gtk_widget_hide(window3);
GtkWidget *window2;
window2 = create_window2 ();
gtk_widget_show (window2);


}


void
on_edit_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window3;
GtkWidget *output;
char ch[100];
window3=lookup_widget(button,"window3");
output=lookup_widget(window3,"ID");
strcpy(ch,gtk_label_get_text(GTK_LABEL(output)));
gtk_widget_hide(window3);
GtkWidget *window4;
window4 = create_window4 ();
gtk_widget_show (window4);
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output8;
output8=lookup_widget(window4,"path");
output1=lookup_widget(window4,"Function");
output2=lookup_widget(window4,"ID1");
output3=lookup_widget(window4,"username");
output4=lookup_widget(window4,"pass");
output5=lookup_widget(window4,"image15");
//output6=lookup_widget(window4,"image15");
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
input1=lookup_widget(window4,"entry6");
input2=lookup_widget(window4,"entry7");
input3=lookup_widget(window4,"entry8");
input4=lookup_widget(window4,"entry9");
showadmin1(output1,output2,output3,output4,output5,output8,input1,input2,input3,input4,ch);


}


void
on_adduser_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
user p;
GtkWidget *window3;
GtkWidget *input1,*input2,*output;
GtkWidget *combobox1;
GtkWidget *treeview1;

window3=lookup_widget(button, "window3");
combobox1=lookup_widget(button, "comboboxentry1");
input1=lookup_widget(button,"entry3");
input2=lookup_widget(button,"entry4");
output=lookup_widget(button,"label43");
treeview1=lookup_widget(window3,"treeview1");

strcpy(p.username,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.password,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.func,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
if ((strcmp(p.username,"")!=0) && (strcmp(p.password,"")!=0) && (strcmp(p.func,"")!=0))
{
add_user(p,output,input1,input2);
show_user(treeview1);
}
else
{gtk_label_set_text(GTK_LABEL(output),"Missing DATA! try again");}

}


void
on_deluser_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
user p;
GtkWidget *window3;
GtkWidget *input1,*input2,*output;
GtkWidget *combobox2;
GtkWidget *treeview2;
window3=lookup_widget(button, "window3");
combobox2=lookup_widget(button, "comboboxentry1");
input1=lookup_widget(button,"entry3");
input2=lookup_widget(button,"entry4");
output=lookup_widget(button,"label43");
treeview2=lookup_widget(window3,"treeview1");

strcpy(p.username,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.password,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.func,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
if ((strcmp(p.username,"")!=0) && (strcmp(p.func,"")!=0))
{
delete_user(p,output);
show_user(treeview2);
}
else
{gtk_label_set_text(GTK_LABEL(output),"Missing DATA! try again");}
 



}


void
on_save1_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_save2_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_gal1_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_gal3_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_gal2_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_gal4_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_gal5_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void on_gal6_clicked (GtkButton       *button,gpointer         user_data)
{

}


void on_doctors_clicked  (GtkButton  *button,gpointer  user_data)
{
					GtkWidget *window3;
					window3=lookup_widget(button, "window3");
					GtkWidget *treeview1;
					treeview1=lookup_widget(window3,"treeview1");
					show_user_as(treeview1,"Nutritionist");

}


void on_coach_clicked  (GtkButton *button,gpointer user_data)
{
					GtkWidget *window3;
					window3=lookup_widget(button, "window3");
					GtkWidget *treeview1;
					treeview1=lookup_widget(window3,"treeview1");
					show_user_as(treeview1,"Coach");
}



void on_client_clicked (GtkButton *button,gpointer user_data)
{
					GtkWidget *window3;
					window3=lookup_widget(button, "window3");
					GtkWidget *treeview1;
					treeview1=lookup_widget(window3,"treeview1");
					show_user_as(treeview1,"Client");
}



void on_all_clicked  (GtkButton       *button,gpointer         user_data)
{
					GtkWidget *window3;
					window3=lookup_widget(button, "window3");
					GtkWidget *treeview1;
					treeview1=lookup_widget(window3,"treeview1");
					show_user(treeview1);


}


void on_dietitian_clicked (GtkButton *button,gpointer user_data)
{
					GtkWidget *window3;
					window3=lookup_widget(button, "window3");
					GtkWidget *treeview1;
					treeview1=lookup_widget(window3,"treeview1");
					show_user_as(treeview1,"Dietitian");
}


void
on_physio_clicked (GtkButton *button,gpointer user_data)
{
					GtkWidget *window3;
					window3=lookup_widget(button, "window3");
					GtkWidget *treeview1;
					treeview1=lookup_widget(window3,"treeview1");
					show_user_as(treeview1,"Physiotherapist");
}


/*void on_importprof_clicked(GtkButton *button,  gpointer user_data)
{

}*/


void on_confirmedit_clicked(GtkButton*button,gpointer user_data)
{
GtkWidget *window4;
GtkWidget *output;
char ch[20],name1[20],fname1[20],phone1[20],mail1[330],path1[100];
window4=lookup_widget(button,"window4");



GtkWidget *output1;
GtkWidget *output2;

output1=lookup_widget(window4,"username");
output2=lookup_widget(window4,"path");

strcpy(ch,gtk_label_get_text(GTK_LABEL(output1)));
strcpy(path1,gtk_label_get_text(GTK_LABEL(output2)));

GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
input1=lookup_widget(window4,"entry6");
input2=lookup_widget(window4,"entry7");
input3=lookup_widget(window4,"entry8");
input4=lookup_widget(window4,"entry9");
strcpy(name1,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(fname1,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(phone1,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(mail1,gtk_entry_get_text(GTK_ENTRY(input4)));
//showadmin1(output1,output2,output3,output4,output5,input1,input2,input3,input4,ch);
modifdata(ch,name1,fname1,phone1,mail1,path1);
					gtk_widget_hide(window4);
					GtkWidget *window3;
					window3= create_window3 ();
					gtk_widget_show (window3);
					GtkWidget *treeview1;
					GtkWidget *output11;
					GtkWidget *output21;
					GtkWidget *output31;
					GtkWidget *output41;
					GtkWidget *output51;
					GtkWidget *output61;
					GtkWidget *output71;	
					/*GtkWidget *output8;
					output2=lookup_widget(window3,"label57");*/
					output11=lookup_widget(window3,"ID");
					output21=lookup_widget(window3,"label57");
					output31=lookup_widget(window3,"name");
					output41=lookup_widget(window3,"Fname");
					output51=lookup_widget(window3,"phone");
					output61=lookup_widget(window3,"mail");
					output71=lookup_widget(window3,"image12");
					showadmin(output11,output21,output31,output41,output51,output61,output71,ch);
					treeview1=lookup_widget(window3,"treeview1");
					show_user(treeview1);
}


void on_anuledit_clicked  (GtkButton       *button,gpointer         user_data)
{
					GtkWidget *window4, *window3;
					window4=lookup_widget(button,"window4");
					GtkWidget *output;
					char ch[100];
					window4=lookup_widget(button,"window4");
					output=lookup_widget(window4,"username");
					gtk_widget_hide(window4);
					strcpy(ch,gtk_label_get_text(GTK_LABEL(output)));
					window3= create_window3 ();
					gtk_widget_show (window3);
					GtkWidget *treeview1;
					GtkWidget *output1;
					GtkWidget *output2;
					GtkWidget *output3;
					GtkWidget *output4;
					GtkWidget *output5;
					GtkWidget *output6;
					GtkWidget *output7;
					//GtkWidget *output8;
					output1=lookup_widget(window3,"ID");
					output2=lookup_widget(window3,"label57");
					output3=lookup_widget(window3,"name");
					output4=lookup_widget(window3,"Fname");
					output5=lookup_widget(window3,"phone");
					output6=lookup_widget(window3,"mail");
					//output8=lookup_widget(window3,"path");
					output7=lookup_widget(window3,"image12");
					showadmin(output1,output2,output3,output4,output5,output6,output7,ch);
					treeview1=lookup_widget(window3,"treeview1");
					show_user(treeview1);

}


void
on_connect_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2,*output;
GtkWidget *window2;
window2=lookup_widget(button,"window2");
int tst=0;
FILE*f;
char username[100],password[100],user[30],pass[30],fun[20],id[5];
input1=lookup_widget(button,"entry1");
input2=lookup_widget(button,"entry2");
output=lookup_widget(button,"msger");
strcpy(username,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2)));
f=fopen("users.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %s %s %s",id,user,pass,fun)!=EOF)
	{
		if(strcmp(username,user)==0 && strcmp(password,pass)==0)
		{
			if (strcmp(fun,"admin") == 0) 

				{
					gtk_widget_hide(window2);
					GtkWidget *window3;
					window3= create_window3 ();
					gtk_widget_show (window3);
					GtkWidget *treeview1;
					GtkWidget *output1;
					GtkWidget *output2;
					GtkWidget *output3;
					GtkWidget *output4;
					GtkWidget *output5;
					GtkWidget *output6;
					GtkWidget *output7;	
					/*GtkWidget *output8;
					output2=lookup_widget(window3,"label57");*/
					output1=lookup_widget(window3,"ID");
					output2=lookup_widget(window3,"label57");
					output3=lookup_widget(window3,"name");
					output4=lookup_widget(window3,"Fname");
					output5=lookup_widget(window3,"phone");
					output6=lookup_widget(window3,"mail");
					output7=lookup_widget(window3,"image12");
					showadmin(output1,output2,output3,output4,output5,output6,output7,username);
					treeview1=lookup_widget(window3,"treeview1");
					show_user(treeview1);
					
					
				}
			        if (strcmp(fun,"Coach") == 0) 

				{	
					gtk_widget_hide(window2);
					GtkWidget *window3;
					window3=create_windowcoach (username);
					gtk_widget_show (window3);
					//GtkWidget *window3;
					//window3= create_window3 ();
					//gtk_widget_show (window3);
					//GtkWidget *treeview2;
					//treeview2=lookup_widget(window3,"treeview2");
					//show_user(treeview2);
				}
			/*block reservé pour les autres utilisateurs*/
			if (strcmp(fun,"Physiotherapist") == 0) 

				{
					gtk_widget_hide(window2);
					GtkWidget *windowk;
					windowk= create_windowkine ();
					gtk_widget_show (windowk);
				}
			if (strcmp(fun,"Client") == 0) 

				{
					gtk_widget_hide(window2);
					GtkWidget *windowk;
					windowk= create_windowad ();
					gtk_widget_show (windowk);
					affich_info(windowk);
					GtkWidget *treeview1a;
					treeview1a=lookup_widget(windowk,"treeview1a");
					afficher_coachs(treeview1a);

				}
			if (strcmp(fun,"Nutritionist") == 0) 

				{
					gtk_widget_hide(window2);
					GtkWidget *windowk;
					windowk= create_NutritionistSpace ();
					gtk_widget_show (windowk);
					/*affich_info(windowk);
					GtkWidget *treeview1a;
					treeview1a=lookup_widget(windowk,"treeview1a");
					afficher_coachs(treeview1a);*/

				}
		}
		else
			{
				gtk_label_set_text(GTK_LABEL(output),"nom d'utilisateur ou mot de passe incorrect");
				gtk_entry_set_text(GTK_ENTRY(input2),"");
				gtk_entry_set_text(GTK_ENTRY(input1),"");
			}
	}

	fclose(f);
	}

}


void
on_back1_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
window2=lookup_widget(button,"window2");
gtk_widget_hide(window2);
GtkWidget *window1;
window1 = create_window1 ();
gtk_widget_show (window1);

}

