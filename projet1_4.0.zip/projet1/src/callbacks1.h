#include <gtk/gtk.h>

GtkWidget* create_windowcoach (char ch[20]);
GtkWidget* create_windowedit (char ch[20]);
GtkWidget* create_windowsch (char ch[20]);
void
on_button3_clicked                     (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);
void toggled_func(GtkCellRendererToggle *cell_renderer, gchar *paths, gpointer user_data);

void
on_button10_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);
typedef struct
{

char day[20];
char month[20];
char year[30];
char hour[30];
char salle[30];
}Date;
enum   
{       
        DAY,
        MONTH,
	YEAR,
        HOUR,
        SALLE,
        SELECTION,
        COLUMNS
};


void afficher_date(GtkWidget *liste);

typedef struct
{
int jour;
int mois;
int annee;
}date;
typedef struct
{
date dt;// -1/-1/-1 si non réserver
char ch1[50];
char ch2[50];
}reservation;
int verif_res(reservation s);
void reserver_date(reservation s);

