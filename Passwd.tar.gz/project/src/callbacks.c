#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "reservation.h"
#include "affiche.h"




void //authentifi
on_button3_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *input1,*input2,*output;
GtkWidget *window1, *window2;
window1=lookup_widget(button,"window1");
int trouve=0;
FILE*f;
char username[20],password[20],user[20],pass[20];
input1=lookup_widget(button,"entry1");
input2=lookup_widget(button,"entry2");
output=lookup_widget(button,"label1");

strcpy(username,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2)));
f=fopen("user names.txt","r");
if(f!=NULL)
{
	while(fscanf(f,"%s %s",user,pass)!=EOF)
	{
		if(strcmp(username,user)==0 && strcmp(password,pass)==0)
		{
			trouve++;
		}
	}
}fclose(f);
if(trouve==0)
{
	gtk_label_set_text(GTK_LABEL(output),"username or password incorrect");
	gtk_entry_set_text(GTK_ENTRY(input2),"");
	gtk_entry_set_text(GTK_ENTRY(input1),"");
}
else 
{
	gtk_widget_hide(window1);
	GtkWidget *window2;
	window2 = create_window2();
	gtk_widget_show (window2);

}
}


void //valide reservation
on_button5_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *combobox1;
 GtkWidget *combobox3;
	GtkWidget *jour;
	GtkWidget *mois;
	GtkWidget *annee;
	GtkWidget *output;
	
	char sort[50];
       
	int r;
	reservation s;
	output=lookup_widget(button,"label29");
	combobox1=lookup_widget(button,"combobox1");
        combobox3=lookup_widget(button,"combobox3");
	jour=lookup_widget(button,"spinbutton1");
	mois=lookup_widget(button,"spinbutton2");
	annee=lookup_widget(button,"spinbutton3");

	s.dt.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
	s.dt.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
	s.dt.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));
	
	if(strcmp("9h==>12h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)		
		strcpy(s.ch1,"9h==>12h");
	else  
		strcpy(s.ch1,"14h==>17h");



        if(strcmp("A",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)))==0)
                strcpy(s.ch2,"A");
        if(strcmp("B",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)))==0)
                strcpy(s.ch2,"B");
        else if (strcmp("C",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)))==0)
               strcpy(s.ch2,"C");
	
	r=verif_res(s);
	
	if(r==1)
		{
		
		strcpy(sort,"date reserved");
		}
	else
		{reserver_date(s);
		strcpy(sort,"date validate");
		
		}
gtk_label_set_text(GTK_LABEL(output), sort);
}


void //Affichaage de treeview
on_button6_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *label21;
GtkWidget *treeview1;



label21=lookup_widget(button,"label21");

      

treeview1=lookup_widget(label21,"treeview1");

afficher_date(treeview1);

}


void //Edit profil
on_button4_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8;
 char Fname[20];
 char Name[20];
 char Speciality[20];
 char Email[50];
 char Pnumber[20];
 int Day;
 int Month;
 int Year;

GtkWidget *window3;
//window3=lookup_widget(button,"window3");
window3 =create_window3 (); 
input1=lookup_widget(window3,"entry8");
input2=lookup_widget(window3,"entry9");
input3=lookup_widget(window3,"combobox6");
input4=lookup_widget(window3,"entry6");
input5=lookup_widget(window3,"entry7");
input6=lookup_widget(window3,"spinbutton10");
input7=lookup_widget(window3,"spinbutton11");
input8=lookup_widget(window3,"spinbutton12");



FILE*f;
f=fopen("Edit.txt","r");
if (f!=NULL)
     		{
             while(fscanf(f,"%s %s %s %s %s %d %d %d \n",Fname,Name,Speciality,Email,Pnumber,&Day,&Month,&Year)!=EOF)   
       		 { 
			
		gtk_entry_set_text(GTK_LABEL(input1),Fname);
		gtk_entry_set_text(GTK_LABEL(input2),Name);
                gtk_entry_set_text(GTK_ENTRY(input4),Email); 
		gtk_entry_set_text(GTK_ENTRY(input5),Pnumber);
                gtk_spin_button_set_value(GTK_SPIN_BUTTON(input6),Day);
                gtk_spin_button_set_value(GTK_SPIN_BUTTON(input7),Month);
                gtk_spin_button_set_value(GTK_SPIN_BUTTON(input8),Year);
                if(strcmp(Speciality,"Bodybuilding")==0)
		{
                gtk_combo_box_set_active(GTK_COMBO_BOX(input3),0);
                }
                else {//(strcmp(Speciality,"Boxe")==0) {
               gtk_combo_box_set_active(GTK_COMBO_BOX(input3),1);
                }
		

		}
    		}

	fclose(f);
GtkWidget *window2;
window2=lookup_widget(button,"window2");
gtk_widget_hide(window2);


gtk_widget_show (window3);





}

void toggled_func(GtkCellRendererToggle *cell_renderer, gchar *paths, gpointer user_data) //fonction de selection date
{
    GtkTreeIter iter;
    GtkTreePath *path;
    FILE* f;
    gboolean boolean;
    gchar *hour;
    gchar *salle;
    gchar *day;
    gchar *month;
    gchar *year;
    path = gtk_tree_path_new_from_string (paths);
    gtk_tree_model_get_iter (GTK_TREE_MODEL (user_data),&iter,path);
    gtk_tree_model_get (GTK_TREE_MODEL (user_data),&iter,SELECTION,&boolean,DAY,&day,MONTH,&month,YEAR,&year,HOUR,&hour,SALLE,&salle,-1);
    gtk_list_store_set (user_data, &iter,SELECTION, !boolean,-1);
    if (!boolean) { //creation de la date dans un fichier tmp
    f=fopen("reservtmp.txt","w");
    fprintf(f,"%s %s %s %s %s\n",day,month,year,hour,salle);
    fclose(f);
}
}


void//modifier
on_button9_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *window2;
FILE *f;
FILE *f1;
reservation s;
window2=lookup_widget(button,"window2");
gtk_widget_hide(window2);
GtkWidget *window4;
window4 =create_window4 ();
GtkWidget* combobox1;
GtkWidget* combobox2;
GtkWidget* spinbutton1;
GtkWidget* spinbutton2;
GtkWidget* spinbutton3;
combobox1=lookup_widget(window4,"combobox4");
combobox2=lookup_widget(window4,"combobox5");
spinbutton1=lookup_widget(window4,"spinbutton7");
spinbutton2=lookup_widget(window4,"spinbutton8");
spinbutton3=lookup_widget(window4,"spinbutton9");
f=fopen("reservtmp.txt","r");
while(fscanf(f,"%d %d %d %s %s \n",&s.dt.jour,&s.dt.mois,&s.dt.annee,s.ch1,s.ch2)!=EOF) {
gtk_spin_button_set_value(GTK_SPIN_BUTTON(spinbutton1),s.dt.jour);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(spinbutton2),s.dt.mois);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(spinbutton3),s.dt.annee);
if(strcmp(s.ch1,"9h==>12h")==0){
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox1),0);
}
else if(strcmp(s.ch1,"14h==>17h")==0) {
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox1),1);
}
if(strcmp(s.ch2,"A")==0){
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox2),0);
}
else if(strcmp(s.ch2,"B")==0) {
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox2),1);
}
else if(strcmp(s.ch2,"C")==0) {
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox2),2);
}
}
fclose(f);


gtk_widget_show (window4); 

}



void //comfirmer modifier date
on_button10_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{ 

reservation s,s1,s2;

char txt[50]="Modify validate";
FILE *f1;
FILE *f2;
FILE *f3;
GtkWidget *output;
GtkWidget *combobox4;
GtkWidget *combobox5;
GtkWidget *spinbutton7;
GtkWidget *spinbutton8;
GtkWidget *spinbutton9;
output=lookup_widget(button,"label54");
combobox4=lookup_widget(button,"combobox4");
combobox5=lookup_widget(button,"combobox5");
spinbutton7=lookup_widget(button,"spinbutton7");
spinbutton8=lookup_widget(button,"spinbutton8");
spinbutton9=lookup_widget(button,"spinbutton9");
        s2.dt.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spinbutton7));
	s2.dt.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spinbutton8));
	s2.dt.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spinbutton9));
	
	if(strcmp("9h==>12h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox4)))==0)		
		strcpy(s2.ch1,"9h==>12h");
	else  
		strcpy(s2.ch1,"14h==>17h");



        if(strcmp("A",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox5)))==0)
                strcpy(s2.ch2,"A");
        if(strcmp("B",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox5)))==0)
                strcpy(s2.ch2,"B");
        else if (strcmp("C",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox5)))==0)
               strcpy(s2.ch2,"C");
f1=fopen("reservtmp.txt","r");
while(fscanf(f1,"%d %d %d %s %s \n",&s.dt.jour,&s.dt.mois,&s.dt.annee,s.ch1,s.ch2)!=EOF){
f2=fopen("reserv.txt","r");
f3=fopen("reserv.tmp","a");
while(fscanf(f2,"%d %d %d %s %s \n",&s1.dt.jour,&s1.dt.mois,&s1.dt.annee,s1.ch1,s1.ch2)!=EOF){
if ((s.dt.jour==s1.dt.jour)&&(s.dt.mois==s1.dt.mois)&&(s.dt.annee==s1.dt.annee)&&(strcmp(s.ch1,s1.ch1)==0)&&(strcmp(s.ch2,s1.ch2)==0)) {
fprintf(f3,"%d %d %d %s %s \n",s2.dt.jour,s2.dt.mois,s2.dt.annee,s2.ch1,s2.ch2);
}
else {

fprintf(f3,"%d %d %d %s %s \n",s1.dt.jour,s1.dt.mois,s1.dt.annee,s1.ch1,s1.ch2);
}
}
fclose(f2);
fclose(f3);
}
fclose(f1);
remove("reserv.txt");
rename("reserv.tmp","reserv.txt");
gtk_label_set_text(GTK_LABEL(output),txt);
}

void//retour de comfirm modifier a calendrier
on_button11_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *window4;
window4=lookup_widget(button,"window4");
gtk_widget_hide(window4);
GtkWidget *window2;
window2 =create_window2 ();
gtk_widget_show (window2); 

}


void //bouton log out
on_button12_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *window2;
window2=lookup_widget(button,"window2");
gtk_widget_hide(window2);
GtkWidget *window1;
window1 =create_window1 ();
gtk_widget_show (window1); 

}


void //retour de modif editprofil
on_button13_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *window3;
window3=lookup_widget(button,"window3");
gtk_widget_hide(window3);
GtkWidget *window2;
window2 =create_window2 ();
gtk_widget_show (window2);

}


void //boutton afficher profil
on_button14_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *output1,*output2,*output3,*output4,*output5,*output6,*output7,*output8;
 char Fname[20];
 char Name[20];
 char Speciality[20];
 char Email[20];
 char Pnumber[20];
 char Day[20];
 char Month[20];
 char Year[20];
 

output1=lookup_widget(button,"label16");
output2=lookup_widget(button,"label17");
output3=lookup_widget(button,"label18");
output4=lookup_widget(button,"label19");
output5=lookup_widget(button,"label20");
output6=lookup_widget(button,"label60");
output7=lookup_widget(button,"label61");
output8=lookup_widget(button,"label62");
FILE*f;
f=fopen("Edit.txt","r");
if (f!=NULL)
     		{
             while(fscanf(f,"%s %s %s %s %s %s %s %s \n",Fname,Name,Speciality,Email,Pnumber,Day,Month,Year)!=EOF)   
       		 { 
			
		gtk_label_set_text(GTK_LABEL(output1),Fname);
		gtk_label_set_text(GTK_LABEL(output2),Name);
		gtk_label_set_text(GTK_LABEL(output3),Speciality);
		gtk_label_set_text(GTK_LABEL(output4),Email);
		gtk_label_set_text(GTK_LABEL(output5),Pnumber);
		gtk_label_set_text(GTK_LABEL(output6),Day);
		gtk_label_set_text(GTK_LABEL(output7),Month);
		gtk_label_set_text(GTK_LABEL(output8),Year);
		

		}
    		}

	fclose(f);
	}




void // bouton delete
on_button15_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{ GtkWidget *liste;
  GtkWidget *window2;
  GtkListStore *store;

char delete[50]="success delete";

reservation s,s1;
FILE* f1;
FILE* f2;
FILE* f3;
window2=lookup_widget(button,"window2");
liste=lookup_widget(window2,"treeview1");
store=gtk_tree_view_get_model(liste);
GtkWidget *output;
output=lookup_widget(button,"label64");
f1=fopen("reservtmp.txt","r");
if(f1!=NULL) {
while (fscanf(f1,"%d %d %d %s %s \n",&s1.dt.jour,&s1.dt.mois,&s1.dt.annee,s1.ch1,s1.ch2)!=EOF){
f2=fopen("reserv.txt","r");
f3=fopen("reserv.tmp","a");
while(fscanf(f2,"%d %d %d %s %s \n",&s.dt.jour,&s.dt.mois,&s.dt.annee,s.ch1,s.ch2)!=EOF){
if ((s.dt.jour!=s1.dt.jour)||(s.dt.mois!=s1.dt.mois)||(s.dt.annee!=s1.dt.annee)||(strcmp(s.ch1,s1.ch1)!=0)||(strcmp(s.ch2,s1.ch2)!=0)) {
fprintf(f3,"%d %d %d %s %s \n",s.dt.jour,s.dt.mois,s.dt.annee,s.ch1,s.ch2);
}}
fclose(f2);
fclose(f3);
}
fclose(f1);
remove("reserv.txt");
rename("reserv.tmp","reserv.txt");

gtk_label_set_text(GTK_LABEL(output), delete);


}}


void //Validate edit profil
on_button7_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
 { GtkWidget *Day;
   GtkWidget *Month; 
   GtkWidget *Year;
   GtkWidget *input1,*input2,*input3,*input4,*input5,*output;
   GtkWidget *combobox6;
   FILE*f;
   int j;
   int m;
   int a;
char Fname[20],Name[20],Email[20],Speciality[50],Pnumber[20];
Day=lookup_widget(button, "spinbutton10");
Month=lookup_widget(button, "spinbutton11");
Year=lookup_widget(button, "spinbutton12");
input1=lookup_widget(button,"entry8");
input2=lookup_widget(button,"entry9");
input4=lookup_widget(button,"entry6");
input5=lookup_widget(button,"entry7");

output=lookup_widget(button,"label75");
        combobox6=lookup_widget(button, "combobox6");
	strcpy(Fname,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(Name,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(Email,gtk_entry_get_text(GTK_ENTRY(input4)));
	strcpy(Pnumber,gtk_entry_get_text(GTK_ENTRY(input5)));
        strcpy(Speciality,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox6)));
        
	
j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Day));
m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Month));
a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Year));
gtk_label_set_text(GTK_LABEL(output),"Save");

f=fopen("Edit.txt","w+");
	if(f!=NULL)
	{
		fprintf(f,"%s %s %s %s %s %d %d %d ",Fname,Name,Speciality,Email,Pnumber,j,m,a);
		fclose(f);
	


}}


void //aller password
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *window3;
window3=lookup_widget(button,"window3");
gtk_widget_hide(window3);
GtkWidget *window5;
window5 =create_window5 ();
gtk_widget_show (window5); 


}


void //retour password
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *window5;
window5=lookup_widget(button,"window5");
gtk_widget_hide(window5);
GtkWidget *window3;
window3 =create_window3 ();
gtk_widget_show (window3); 


}


void // validation password
on_button17_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *window5;
window5=lookup_widget(button,"window5");
GtkWidget *input1,*input2,*input3,*output;
char confirm[20],newpass[20],oldpass[20],password[20],username[20];
FILE*f;

input1=lookup_widget(button,"entry10");
input2=lookup_widget(button,"entry11");
input3=lookup_widget(button,"entry12");
output=lookup_widget(button,"label81");

strcpy(oldpass,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(newpass,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(confirm,gtk_entry_get_text(GTK_ENTRY(input3)));

f=fopen("user names.txt","r");
	if(f!=NULL)
	{
		fscanf(f,"%s %s ",username, password);
		fclose(f);
	}



if(strcmp(newpass,confirm)==0 && strcmp(oldpass,password)==0)
{

	f=fopen("user names.txt","w");
	if(f!=NULL)
	{
		fprintf(f,"%s %s ",username, newpass);
		fclose(f);
	}

	gtk_label_set_text(GTK_LABEL(output),"password updated");
	gtk_entry_set_text(GTK_ENTRY(input1),"");
	gtk_entry_set_text(GTK_ENTRY(input2),"");
	gtk_entry_set_text(GTK_ENTRY(input3),"");

}
else 
{
	gtk_label_set_text(GTK_LABEL(output),"Error ! try again");
	gtk_entry_set_text(GTK_ENTRY(input1),"");
	gtk_entry_set_text(GTK_ENTRY(input2),"");
	gtk_entry_set_text(GTK_ENTRY(input3),"");

}

}

