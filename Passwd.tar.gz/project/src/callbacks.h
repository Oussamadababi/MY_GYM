#include <gtk/gtk.h>


void
on_button3_clicked                     (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);
void toggled_func(GtkCellRendererToggle *cell_renderer, gchar *paths, gpointer user_data);

void
on_button10_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button17_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
