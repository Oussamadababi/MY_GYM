#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif




#include <stdio.h>
#include <string.h>
#include "affiche.h"
#include <gtk/gtk.h> 
#include "callbacks.h"
void afficher_date(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char day [30];
	char month [30];
	char year [30];
        char hour [30];
        char salle [30];
        store=NULL;

       FILE *f;
	
	store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  day", renderer, "text",DAY, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" month", renderer, "text",MONTH, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  year", renderer, "text",YEAR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	        renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" hour", renderer, "text",HOUR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
                 
                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" salle", renderer, "text",SALLE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

                renderer = gtk_cell_renderer_toggle_new ();
		column = gtk_tree_view_column_new_with_attributes(" select", renderer, "active",SELECTION, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	}

	
	store=gtk_list_store_new (6, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING ,G_TYPE_BOOLEAN);
        f = fopen("reserv.txt", "r");
	
	if(f==NULL)
	{

		return;
	}		
	else 

	{ f = fopen("reserv.txt", "a+");
              while(fscanf(f,"%s %s %s %s %s \n",day,month,year,hour,salle)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, DAY, day, MONTH, month, YEAR, year,HOUR,hour,SALLE,salle,SELECTION,FALSE, -1); 
		}
		fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
        g_signal_connect(G_OBJECT(renderer),"toggled", (GCallback)toggled_func,store);
    
	}
}



