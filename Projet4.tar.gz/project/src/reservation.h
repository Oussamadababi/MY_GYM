typedef struct
{
int jour;
int mois;
int annee;
}date;
typedef struct
{
date dt;// -1/-1/-1 si non réserver
char ch1[50];
char ch2[50];
}reservation;
int verif_res(reservation s);
void reserver_date(reservation s);






