#include <gtk/gtk.h>

typedef struct
{

char day[20];
char month[20];
char year[30];
char hour[30];
char salle[30];
}Date;
enum   
{       
        DAY,
        MONTH,
	YEAR,
        HOUR,
        SALLE,
        SELECTION,
        COLUMNS
};


void afficher_date(GtkWidget *liste);
