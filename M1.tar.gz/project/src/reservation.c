#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "reservation.h"
int verif_res(reservation s)
{
int v=0; // date non reserver
reservation res;
FILE*f;
f=fopen("reserv.txt","r");
if(f!=NULL)
{
	while(!v && fscanf(f,"%d %d %d %s %s",&res.dt.jour,&res.dt.mois,&res.dt.annee,&res.ch1,&res.ch2)!=EOF)
	{


			if ((res.dt.jour==s.dt.jour) && (res.dt.mois==s.dt.mois) && (res.dt.annee==s.dt.annee) && (strcmp(res.ch1,s.ch1)==0) && (strcmp(res.ch2,s.ch2)==0))
					{v=1;}	
	}

}

fclose(f);
	
return v;
}
void reserver_date(reservation s)
{
	FILE*f;
        f=fopen("reserv.txt","a+");
	if(f!=NULL)
	{
	fprintf(f,"%d %d %d %s %s\n",s.dt.jour,s.dt.mois,s.dt.annee,s.ch1,s.ch2);
	fclose(f);
	}
}
