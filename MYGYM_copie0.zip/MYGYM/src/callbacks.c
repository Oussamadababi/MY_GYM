#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include "user.h"


void on_button2_clicked (GtkButton  *button, gpointer user_data)
{
	GtkWidget *window1 , *output;
FILE*f;
char ch1[400],ch2[400],ch3[400],ch4[400],ch11[10000]={0},ch22[10000]={0},ch33[10000]={0},ch44[10000]={0};
window1=lookup_widget(button,"window1");
gtk_widget_hide(window1);
GtkWidget *window4;
window4 = create_window4 ();
gtk_widget_show (window4);
output=lookup_widget(window4,"label30");
f=fopen("creation.txt","r");
if(f!=NULL){
while (fgets(ch1,400,f)!=NULL)//(f,"%s",ch1)!=EOF)
{strcat(ch11,ch1);
strcat(ch11,"\n");
}
fclose(f);
gtk_label_set_text(GTK_LABEL(output),ch11);}

output=lookup_widget(window4,"label32");
f=fopen("ad.txt","r");
if(f!=NULL){
while (fgets(ch2,400,f)!=NULL)//(f,"%s",ch1)!=EOF)
{strcat(ch22,ch2);
strcat(ch22,"\n");
}
fclose(f);
gtk_label_set_text(GTK_LABEL(output),ch22);}
output=lookup_widget(window4,"label34");
f=fopen("location.txt","r");
if(f!=NULL){
while (fgets(ch3,400,f)!=NULL)//(f,"%s",ch1)!=EOF)
{strcat(ch33,ch3);
strcat(ch33,"\n");
}
fclose(f);
gtk_label_set_text(GTK_LABEL(output),ch33);}
output=lookup_widget(window4,"label36");
f=fopen("natiotrop.txt","r");
if(f!=NULL){
while (fgets(ch4,400,f)!=NULL)//(f,"%s",ch1)!=EOF)
{strcat(ch44,ch4);
strcat(ch44,"\n");}
fclose(f);
gtk_label_set_text(GTK_LABEL(output),ch44);}
}



void on_button1_clicked (GtkButton *button,gpointer user_data)
{
GtkWidget *window1;
window1=lookup_widget(button,"window1");
gtk_widget_hide(window1);
GtkWidget *window2;
window2 = create_window2 ();
gtk_widget_show (window2);

}
void on_button3_clicked (GtkButton *button,gpointer user_data)
{
GtkWidget *window2;
window2=lookup_widget(button,"window2");
gtk_widget_hide(window2);
GtkWidget *window1;
window1 =create_window1 ();
gtk_widget_show (window1);
}
void on_button4_clicked (GtkButton  *button,gpointer user_data) //Authentification 
{
GtkWidget *input1,*input2,*input3,*output;
GtkWidget *window2;
window2=lookup_widget(button,"window2");
int tst=0;
FILE*f;
char username[100],password[100],user[30],pass[30],fun[20];
input1=lookup_widget(button,"entry1");
input2=lookup_widget(button,"entry2");
output=lookup_widget(button,"label4");
strcpy(username,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2)));
f=fopen("user.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %s %s",user,pass,fun)!=EOF)
	{
		if(strcmp(username,user)==0 && strcmp(password,pass)==0)
		{
			if (strcmp(fun,"admin") == 0) 

				{
					gtk_widget_hide(window2);
					GtkWidget *window3;
					window3= create_window3 ();
					gtk_widget_show (window3);
					GtkWidget *treeview2;
					treeview2=lookup_widget(window3,"treeview2");
					show_user(treeview2);
				}
			if (strcmp(fun,"Coach") == 0) 

				{	
					gtk_widget_hide(window2);
					GtkWidget *window3;
					window3=create_window_coach (username);
					gtk_widget_show (window3);
					/*GtkWidget *window3;
					/*window3= create_window3 ();
					gtk_widget_show (window3);
					GtkWidget *treeview2;
					treeview2=lookup_widget(window3,"treeview2");
					show_user(treeview2);*/
				}
			/*block reservé pour les autres utilisateurs
			if (strcmp(fun,"") == 0) 

				{
					gtk_widget_hide(window2);
					GtkWidget *windowXX;
					window= create_windowXX ();
					gtk_widget_show (windowXX);
				}*/
		}
		else
			{
				gtk_label_set_text(GTK_LABEL(output),"nom d'utilisateur ou mot de passe incorrect");
				gtk_entry_set_text(GTK_ENTRY(input2),"");
				gtk_entry_set_text(GTK_ENTRY(input1),"");
			}
	}

	fclose(f);
	}

}


void on_button5_clicked (GtkButton       *button,gpointer         user_data) //ajouter un utilisateur
{
user p;
GtkWidget *window3;
GtkWidget *input1,*input2,*output;
GtkWidget *combobox2;
GtkWidget *treeview2;
//char ch1[400],ch0[200];
window3=lookup_widget(button, "window3");
combobox2=lookup_widget(button, "comboboxentry2");
input1=lookup_widget(button,"entry3");
input2=lookup_widget(button,"entry4");
output=lookup_widget(button,"label20");
treeview2=lookup_widget(window3,"treeview2");
//show_user(treeview2);
/*strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(input1)));
strcat(ch1," ");
strcat(ch1,gtk_entry_get_text(GTK_ENTRY(input2)));
strcat(ch1," ");
strcpy(ch0,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2))); 
strcat(ch1,ch0);
strcat(ch1,"\n");
FILE *f;
f=fopen("user.txt","a+");
	if(f!=NULL)
	{
		fprintf(f,"%s",ch1);
		fclose(f);
	}
gtk_entry_set_text(GTK_ENTRY(input1),"");
gtk_entry_set_text(GTK_ENTRY(input2),"");*/
strcpy(p.username,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.password,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.func,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
add_user(p,output,input1,input2);


//gtk_label_set_text(GTK_LABEL(output),"user succefuly added !!!");
show_user(treeview2);
/*gtk_entry_set_text(GTK_ENTRY(input1),"");
gtk_entry_set_text(GTK_ENTRY(input2),"");*/




}


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window4;
window4=lookup_widget(button,"window4");
gtk_widget_hide(window4);
GtkWidget *window1;
window1 =create_window1 ();
gtk_widget_show (window1);

}




void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog;
GtkWidget *window3;
window3=lookup_widget(button,"window3");
GtkWidget *output;
output=lookup_widget(button,"image11");
char *filename;
dialog = gtk_file_chooser_dialog_new ("openfile",
                                      window3,
                                      GTK_FILE_CHOOSER_ACTION_OPEN,
                                      GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                                      GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
                                      NULL);

if (gtk_dialog_run (GTK_DIALOG (dialog)) == GTK_RESPONSE_ACCEPT)
  {
    

    filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
    //open_file (filename);
    //g_free (filename);
  

gtk_widget_destroy (dialog);
//gtk_image_set_from_file (output,filename);
//open_file (filename);
//g_free (filename);
}
gtk_image_set_from_file (output,filename);
g_free (filename);
}


void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window3;
window3=lookup_widget(button,"window3");
gtk_widget_hide(window3);
GtkWidget *window2;
window2 =create_window2();
gtk_widget_show (window2);


}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
user p;
GtkWidget *window3;
GtkWidget *input1,*input2,*output;
GtkWidget *combobox2;
GtkWidget *treeview2;
window3=lookup_widget(button, "window3");
combobox2=lookup_widget(button, "comboboxentry2");
input1=lookup_widget(button,"entry3");
input2=lookup_widget(button,"entry4");
output=lookup_widget(button,"label20");
treeview2=lookup_widget(window3,"treeview2");

strcpy(p.username,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.password,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.func,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
delete_user(p,output);



show_user(treeview2);

}

