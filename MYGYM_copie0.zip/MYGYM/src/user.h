#include <gtk/gtk.h>
typedef struct
{
char username[20];
char password[30];
char func[20];
}user;
void add_user(user p,GtkWidget *output,GtkWidget *input1,GtkWidget *input2);
void show_user(GtkWidget *list);
void delete_user(user p,GtkWidget *output);
