#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include "user.h"
#include "interface_admin.h"

void on_button5_clicked (GtkWidget       *button,gpointer         user_data,char ch1[20]) //ajouter un utilisateur
{
user p;
GtkWidget *window3;
GtkWidget *input1,*input2,*output;
GtkWidget *combobox2;
GtkWidget *treeview2;
//char ch1[400],ch0[200];
window3=lookup_widget(button, ch1);
combobox2=lookup_widget(button, "comboboxentry2");
input1=lookup_widget(button,"entry3");
input2=lookup_widget(button,"entry4");
output=lookup_widget(button,"label20");
treeview2=lookup_widget(window3,"treeview2");
//show_user(treeview2);
/*strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(input1)));
strcat(ch1," ");
strcat(ch1,gtk_entry_get_text(GTK_ENTRY(input2)));
strcat(ch1," ");
strcpy(ch0,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2))); 
strcat(ch1,ch0);
strcat(ch1,"\n");
FILE *f;
f=fopen("user.txt","a+");
	if(f!=NULL)
	{
		fprintf(f,"%s",ch1);
		fclose(f);
	}
gtk_entry_set_text(GTK_ENTRY(input1),"");
gtk_entry_set_text(GTK_ENTRY(input2),"");*/
strcpy(p.username,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.password,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.func,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
add_user(p,output,input1,input2);


//gtk_label_set_text(GTK_LABEL(output),"user succefuly added !!!");
show_user(treeview2);
/*gtk_entry_set_text(GTK_ENTRY(input1),"");
gtk_entry_set_text(GTK_ENTRY(input2),"");*/




}
void
on_button10_clicked                    (GtkWidget       *button,
                                        gpointer         user_data,char ch1[20])
{
GtkWidget *dialog;
GtkWidget *window3;
window3=lookup_widget(button,ch1);
GtkWidget *output;
output=lookup_widget(button,"image11");
char *filename;
dialog = gtk_file_chooser_dialog_new ("openfile",
                                      window3,
                                      GTK_FILE_CHOOSER_ACTION_OPEN,
                                      GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                                      GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
                                      NULL);

if (gtk_dialog_run (GTK_DIALOG (dialog)) == GTK_RESPONSE_ACCEPT)
  {
    

	filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
    	gtk_widget_destroy (dialog);
}
gtk_image_set_from_file (output,filename);
g_free (filename);
}


void
on_button11_clicked                    (GtkWidget       *button,
                                        gpointer         user_data,char ch1[20])
{
GtkWidget *window3;
window3=lookup_widget(button,ch1);
gtk_widget_hide(window3);
GtkWidget *window2;
window2 =create_window2();
gtk_widget_show (window2);


}
void
on_button8_clicked                     (GtkWidget       *button,
                                        gpointer         user_data,char ch1[20])
{
user p;
GtkWidget *window3;
GtkWidget *input1,*input2,*output;
GtkWidget *combobox2;
GtkWidget *treeview2;
window3=lookup_widget(button, ch1);
combobox2=lookup_widget(button, "comboboxentry2");
input1=lookup_widget(button,"entry3");
input2=lookup_widget(button,"entry4");
output=lookup_widget(button,"label20");
treeview2=lookup_widget(window3,"treeview2");

strcpy(p.username,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.password,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.func,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
delete_user(p,output);



show_user(treeview2);

}
