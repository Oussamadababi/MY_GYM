#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>

#include <gdk/gdkkeysyms.h>
#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "user.h"
#define GLADE_HOOKUP_OBJECT(component,widget,name) \
  g_object_set_data_full (G_OBJECT (component), name, \
    gtk_widget_ref (widget), (GDestroyNotify) gtk_widget_unref)

#define GLADE_HOOKUP_OBJECT_NO_REF(component,widget,name) \
  g_object_set_data (G_OBJECT (component), name, widget)

GtkWidget*
create_window_admin (char ch1[20])
{ 
  gpointer user_data;
  GtkWidget *window3;
  GtkWidget *notebook1;
  GtkWidget *fixed2;
  GtkWidget *image11;
  GtkWidget *button10;
  GtkWidget *button11;
  GtkWidget *label5;
  GtkWidget *fixed4;
  GtkWidget *entry3;
  GtkWidget *entry4;
  GtkWidget *label15;
  GtkWidget *label16;
  GtkWidget *label19;
  GtkWidget *button5;
  GtkWidget *treeview2;
  GtkWidget *label20;
  GtkWidget *comboboxentry2;
  GtkWidget *button8;
  GtkWidget *label7;
  GtkWidget *notebook2;
  GtkWidget *empty_notebook_page;
  GtkWidget *label10;
  GtkWidget *label11;
  GtkWidget *label12;
  GtkWidget *label13;
  GtkWidget *label14;
  GtkWidget *label9;

  window3 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window3), _(ch1));

  notebook1 = gtk_notebook_new ();
  gtk_widget_show (notebook1);
  gtk_container_add (GTK_CONTAINER (window3), notebook1);

  fixed2 = gtk_fixed_new ();
  gtk_widget_show (fixed2);
  gtk_container_add (GTK_CONTAINER (notebook1), fixed2);

  image11 = create_pixmap (window3, NULL);
  gtk_widget_show (image11);
  gtk_fixed_put (GTK_FIXED (fixed2), image11, 0, 0);
  gtk_widget_set_size_request (image11, 464, 336);

  button10 = gtk_button_new_with_mnemonic (_("import File"));
  gtk_widget_show (button10);
  gtk_fixed_put (GTK_FIXED (fixed2), button10, 24, 344);
  gtk_widget_set_size_request (button10, 152, 48);

  button11 = gtk_button_new_with_mnemonic (_("Disconnect"));
  gtk_widget_show (button11);
  gtk_fixed_put (GTK_FIXED (fixed2), button11, 936, 504);
  gtk_widget_set_size_request (button11, 112, 56);

  label5 = gtk_label_new (_("Profile"));
  gtk_widget_show (label5);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook1), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook1), 0), label5);

  fixed4 = gtk_fixed_new ();
  gtk_widget_show (fixed4);
  gtk_container_add (GTK_CONTAINER (notebook1), fixed4);

  entry3 = gtk_entry_new ();
  gtk_widget_show (entry3);
  gtk_fixed_put (GTK_FIXED (fixed4), entry3, 184, 32);
  gtk_widget_set_size_request (entry3, 264, 32);
  gtk_entry_set_invisible_char (GTK_ENTRY (entry3), 8226);

  entry4 = gtk_entry_new ();
  gtk_widget_show (entry4);
  gtk_fixed_put (GTK_FIXED (fixed4), entry4, 184, 112);
  gtk_widget_set_size_request (entry4, 264, 32);
  gtk_entry_set_invisible_char (GTK_ENTRY (entry4), 8226);

  label15 = gtk_label_new (_("User name :"));
  gtk_widget_show (label15);
  gtk_fixed_put (GTK_FIXED (fixed4), label15, 0, 24);
  gtk_widget_set_size_request (label15, 200, 40);

  label16 = gtk_label_new (_("password :"));
  gtk_widget_show (label16);
  gtk_fixed_put (GTK_FIXED (fixed4), label16, 56, 120);
  gtk_widget_set_size_request (label16, 88, 24);

  label19 = gtk_label_new (_("user fuction :"));
  gtk_widget_show (label19);
  gtk_fixed_put (GTK_FIXED (fixed4), label19, 40, 200);
  gtk_widget_set_size_request (label19, 112, 56);

  button5 = gtk_button_new_with_mnemonic (_("add"));
  gtk_widget_show (button5);
  gtk_fixed_put (GTK_FIXED (fixed4), button5, 32, 264);
  gtk_widget_set_size_request (button5, 216, 56);
  gtk_container_set_border_width (GTK_CONTAINER (button5), 2);

  treeview2 = gtk_tree_view_new ();
  gtk_widget_show (treeview2);
  gtk_fixed_put (GTK_FIXED (fixed4), treeview2, 600, 0);
  gtk_widget_set_size_request (treeview2, 496, 608);

  label20 = gtk_label_new ("");
  gtk_widget_show (label20);
  gtk_fixed_put (GTK_FIXED (fixed4), label20, 112, 336);
  gtk_widget_set_size_request (label20, 384, 48);

  comboboxentry2 = gtk_combo_box_entry_new_text ();
  gtk_widget_show (comboboxentry2);
  gtk_fixed_put (GTK_FIXED (fixed4), comboboxentry2, 192, 208);
  gtk_widget_set_size_request (comboboxentry2, 253, 29);
  gtk_combo_box_append_text (GTK_COMBO_BOX (comboboxentry2), _("Client"));
  gtk_combo_box_append_text (GTK_COMBO_BOX (comboboxentry2), _("Nutritionist"));
  gtk_combo_box_append_text (GTK_COMBO_BOX (comboboxentry2), _("Coach"));
  gtk_combo_box_append_text (GTK_COMBO_BOX (comboboxentry2), _("Dietitian"));
  gtk_combo_box_append_text (GTK_COMBO_BOX (comboboxentry2), _("Physiotherapist"));

  button8 = gtk_button_new_with_mnemonic (_("Delete"));
  gtk_widget_show (button8);
  gtk_fixed_put (GTK_FIXED (fixed4), button8, 280, 264);
  gtk_widget_set_size_request (button8, 188, 53);

  label7 = gtk_label_new (_(" Users manegment"));
  gtk_widget_show (label7);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook1), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook1), 1), label7);

  notebook2 = gtk_notebook_new ();
  gtk_widget_show (notebook2);
  gtk_container_add (GTK_CONTAINER (notebook1), notebook2);

  empty_notebook_page = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (empty_notebook_page);
  gtk_container_add (GTK_CONTAINER (notebook2), empty_notebook_page);

  label10 = gtk_label_new (_("label10"));
  gtk_widget_show (label10);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook2), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook2), 0), label10);

  empty_notebook_page = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (empty_notebook_page);
  gtk_container_add (GTK_CONTAINER (notebook2), empty_notebook_page);

  label11 = gtk_label_new (_("label11"));
  gtk_widget_show (label11);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook2), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook2), 1), label11);

  empty_notebook_page = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (empty_notebook_page);
  gtk_container_add (GTK_CONTAINER (notebook2), empty_notebook_page);

  label12 = gtk_label_new (_("label12"));
  gtk_widget_show (label12);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook2), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook2), 2), label12);

  empty_notebook_page = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (empty_notebook_page);
  gtk_container_add (GTK_CONTAINER (notebook2), empty_notebook_page);

  label13 = gtk_label_new (_("label13"));
  gtk_widget_show (label13);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook2), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook2), 3), label13);

  empty_notebook_page = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (empty_notebook_page);
  gtk_container_add (GTK_CONTAINER (notebook2), empty_notebook_page);

  label14 = gtk_label_new (_("label14"));
  gtk_widget_show (label14);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook2), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook2), 4), label14);

  label9 = gtk_label_new (_("MY GYM"));
  gtk_widget_show (label9);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook1), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook1), 2), label9);

  g_signal_connect ((gpointer) button10, "clicked",
                    G_CALLBACK (on_button10_clicked),
                    NULL);
  g_signal_connect ((gpointer) button11, "clicked",
                    G_CALLBACK (on_button11_clicked),
                    NULL);
  g_signal_connect ((gpointer) button5, "clicked",
                    G_CALLBACK (on_button5_clicked),
                    NULL);
  g_signal_connect ((gpointer) button8, "clicked",
                    G_CALLBACK (on_button8_clicked),
                    NULL);

  /* Store pointers to all widgets, for use by lookup_widget(). */
  GLADE_HOOKUP_OBJECT_NO_REF (window3, window3, ch1);
  GLADE_HOOKUP_OBJECT (window3, notebook1, "notebook1");
  GLADE_HOOKUP_OBJECT (window3, fixed2, "fixed2");
  GLADE_HOOKUP_OBJECT (window3, image11, "image11");
  GLADE_HOOKUP_OBJECT (window3, button10, "button10");
  GLADE_HOOKUP_OBJECT (window3, button11, "button11");
  GLADE_HOOKUP_OBJECT (window3, label5, "label5");
  GLADE_HOOKUP_OBJECT (window3, fixed4, "fixed4");
  GLADE_HOOKUP_OBJECT (window3, entry3, "entry3");
  GLADE_HOOKUP_OBJECT (window3, entry4, "entry4");
  GLADE_HOOKUP_OBJECT (window3, label15, "label15");
  GLADE_HOOKUP_OBJECT (window3, label16, "label16");
  GLADE_HOOKUP_OBJECT (window3, label19, "label19");
  GLADE_HOOKUP_OBJECT (window3, button5, "button5");
  GLADE_HOOKUP_OBJECT (window3, treeview2, "treeview2");
  GLADE_HOOKUP_OBJECT (window3, label20, "label20");
  GLADE_HOOKUP_OBJECT (window3, comboboxentry2, "comboboxentry2");
  GLADE_HOOKUP_OBJECT (window3, button8, "button8");
  GLADE_HOOKUP_OBJECT (window3, label7, "label7");
  GLADE_HOOKUP_OBJECT (window3, notebook2, "notebook2");
  GLADE_HOOKUP_OBJECT (window3, label10, "label10");
  GLADE_HOOKUP_OBJECT (window3, label11, "label11");
  GLADE_HOOKUP_OBJECT (window3, label12, "label12");
  GLADE_HOOKUP_OBJECT (window3, label13, "label13");
  GLADE_HOOKUP_OBJECT (window3, label14, "label14");
  GLADE_HOOKUP_OBJECT (window3, label9, "label9");

  //return window3;

 on_button5_clicked (button5 ,user_data,ch1); //ajouter un utilisateur
/*{
user p;
GtkWidget *window3;
GtkWidget *input1,*input2,*output;
GtkWidget *combobox2;
GtkWidget *treeview2;
//char ch1[400],ch0[200];
window3=lookup_widget(button, ch1);
combobox2=lookup_widget(button, "comboboxentry2");
input1=lookup_widget(button,"entry3");
input2=lookup_widget(button,"entry4");
output=lookup_widget(button,"label20");
treeview2=lookup_widget(window3,"treeview2");
//show_user(treeview2);
/*strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(input1)));
strcat(ch1," ");
strcat(ch1,gtk_entry_get_text(GTK_ENTRY(input2)));
strcat(ch1," ");
strcpy(ch0,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2))); 
strcat(ch1,ch0);
strcat(ch1,"\n");
FILE *f;
f=fopen("user.txt","a+");
	if(f!=NULL)
	{
		fprintf(f,"%s",ch1);
		fclose(f);
	}
gtk_entry_set_text(GTK_ENTRY(input1),"");
gtk_entry_set_text(GTK_ENTRY(input2),"");*/
/*strcpy(p.username,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.password,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.func,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
add_user(p,output,input1,input2);


//gtk_label_set_text(GTK_LABEL(output),"user succefuly added !!!");
show_user(treeview2);
/*gtk_entry_set_text(GTK_ENTRY(input1),"");
gtk_entry_set_text(GTK_ENTRY(input2),"");*/




//}

on_button10_clicked                    (button10,
                                         user_data,ch1);
/*{
GtkWidget *dialog;
GtkWidget *window3;
window3=lookup_widget(button,ch1);
GtkWidget *output;
output=lookup_widget(button,"image11");
char *filename;
dialog = gtk_file_chooser_dialog_new ("openfile",
                                      window3,
                                      GTK_FILE_CHOOSER_ACTION_OPEN,
                                      GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                                      GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
                                      NULL);

if (gtk_dialog_run (GTK_DIALOG (dialog)) == GTK_RESPONSE_ACCEPT)
  {
    

	filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
    	gtk_widget_destroy (dialog);
}
gtk_image_set_from_file (output,filename);
g_free (filename);
}*/



on_button11_clicked                    (button11,
                                         user_data,ch1);
/*{
GtkWidget *window3;
window3=lookup_widget(button,ch1);
gtk_widget_hide(window3);
GtkWidget *window2;
window2 =create_window2();
gtk_widget_show (window2);


}*/

on_button8_clicked                     (button8,
                                        user_data,ch1);
/*{
user p;
GtkWidget *window3;
GtkWidget *input1,*input2,*output;
GtkWidget *combobox2;
GtkWidget *treeview2;
window3=lookup_widget(button, ch1);
combobox2=lookup_widget(button, "comboboxentry2");
input1=lookup_widget(button,"entry3");
input2=lookup_widget(button,"entry4");
output=lookup_widget(button,"label20");
treeview2=lookup_widget(window3,"treeview2");

strcpy(p.username,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.password,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.func,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
delete_user(p,output);



show_user(treeview2);

}*/
return window3;

}




