#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>

#include <gdk/gdkkeysyms.h>
#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#define GLADE_HOOKUP_OBJECT(component,widget,name) \
  g_object_set_data_full (G_OBJECT (component), name, \
    gtk_widget_ref (widget), (GDestroyNotify) gtk_widget_unref)

#define GLADE_HOOKUP_OBJECT_NO_REF(component,widget,name) \
  g_object_set_data (G_OBJECT (component), name, widget)

GtkWidget*
create_window_coach (char ch[100])
{
  GtkWidget *window2;
  GtkWidget *notebook1;
  GtkWidget *fixed2;
  GtkWidget *label11;
  GtkWidget *button4;
  GtkWidget *label12;
  GtkWidget *label13;
  GtkWidget *label15;
  GtkWidget *label14;
  GtkWidget *label20;
  GtkWidget *label16;
  GtkWidget *label17;
  GtkWidget *label18;
  GtkWidget *label19;
  GtkWidget *label30;
  GtkWidget *label31;
  GtkWidget *label32;
  GtkWidget *label34;
  GtkWidget *label33;
  GtkWidget *label7;
  GtkWidget *notebook2;
  GtkWidget *fixed3;
  GtkWidget *fixed4;
  GtkObject *spinbutton1_adj;
  GtkWidget *spinbutton1;
  GtkWidget *label25;
  GtkWidget *label24;
  GtkWidget *label26;
  GtkWidget *label27;
  GtkObject *spinbutton2_adj;
  GtkWidget *spinbutton2;
  GtkObject *spinbutton3_adj;
  GtkWidget *spinbutton3;
  GtkWidget *label28;
  GtkWidget *combobox1;
  GtkWidget *button5;
  GtkWidget *label29;
  GtkWidget *treeview1;
  GtkWidget *button6;
  GtkWidget *label21;
  GtkWidget *empty_notebook_page;
  GtkWidget *label22;
  GtkWidget *label23;
  GtkWidget *label8;
  GtkWidget *label9;
  GtkWidget *label10;

  window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window2), _(ch));

  notebook1 = gtk_notebook_new ();
  gtk_widget_show (notebook1);
  gtk_container_add (GTK_CONTAINER (window2), notebook1);

  fixed2 = gtk_fixed_new ();
  gtk_widget_show (fixed2);
  gtk_container_add (GTK_CONTAINER (notebook1), fixed2);

  label11 = gtk_label_new (_("First name"));
  gtk_widget_show (label11);
  gtk_fixed_put (GTK_FIXED (fixed2), label11, 32, 32);
  gtk_widget_set_size_request (label11, 97, 24);

  button4 = gtk_button_new_with_mnemonic (_("Edit Profil"));
  gtk_widget_show (button4);
  gtk_fixed_put (GTK_FIXED (fixed2), button4, 528, 16);
  gtk_widget_set_size_request (button4, 90, 32);

  label12 = gtk_label_new (_("name"));
  gtk_widget_show (label12);
  gtk_fixed_put (GTK_FIXED (fixed2), label12, 56, 80);
  gtk_widget_set_size_request (label12, 65, 24);

  label13 = gtk_label_new (_("Phone number "));
  gtk_widget_show (label13);
  gtk_fixed_put (GTK_FIXED (fixed2), label13, 16, 128);
  gtk_widget_set_size_request (label13, 105, 24);

  label15 = gtk_label_new (_("Date of birth "));
  gtk_widget_show (label15);
  gtk_fixed_put (GTK_FIXED (fixed2), label15, 0, 216);
  gtk_widget_set_size_request (label15, 161, 40);

  label14 = gtk_label_new (_("Email"));
  gtk_widget_show (label14);
  gtk_fixed_put (GTK_FIXED (fixed2), label14, 64, 176);
  gtk_widget_set_size_request (label14, 49, 17);

  label20 = gtk_label_new ("");
  gtk_widget_show (label20);
  gtk_fixed_put (GTK_FIXED (fixed2), label20, 168, 224);
  gtk_widget_set_size_request (label20, 193, 32);

  label16 = gtk_label_new ("");
  gtk_widget_show (label16);
  gtk_fixed_put (GTK_FIXED (fixed2), label16, 136, 32);
  gtk_widget_set_size_request (label16, 89, 24);

  label17 = gtk_label_new ("");
  gtk_widget_show (label17);
  gtk_fixed_put (GTK_FIXED (fixed2), label17, 144, 80);
  gtk_widget_set_size_request (label17, 81, 24);

  label18 = gtk_label_new ("");
  gtk_widget_show (label18);
  gtk_fixed_put (GTK_FIXED (fixed2), label18, 152, 128);
  gtk_widget_set_size_request (label18, 129, 24);

  label19 = gtk_label_new ("");
  gtk_widget_show (label19);
  gtk_fixed_put (GTK_FIXED (fixed2), label19, 176, 168);
  gtk_widget_set_size_request (label19, 193, 24);

  label30 = gtk_label_new (_("label30"));
  gtk_widget_show (label30);
  gtk_fixed_put (GTK_FIXED (fixed2), label30, 160, 40);
  gtk_widget_set_size_request (label30, 49, 17);

  label31 = gtk_label_new (_("label31"));
  gtk_widget_show (label31);
  gtk_fixed_put (GTK_FIXED (fixed2), label31, 152, 88);
  gtk_widget_set_size_request (label31, 49, 17);

  label32 = gtk_label_new (_("label32"));
  gtk_widget_show (label32);
  gtk_fixed_put (GTK_FIXED (fixed2), label32, 144, 128);
  gtk_widget_set_size_request (label32, 49, 17);

  label34 = gtk_label_new (_("label34"));
  gtk_widget_show (label34);
  gtk_fixed_put (GTK_FIXED (fixed2), label34, 144, 176);
  gtk_widget_set_size_request (label34, 49, 17);

  label33 = gtk_label_new (_("label33"));
  gtk_widget_show (label33);
  gtk_fixed_put (GTK_FIXED (fixed2), label33, 160, 224);
  gtk_widget_set_size_request (label33, 49, 17);

  label7 = gtk_label_new (_("Profil"));
  gtk_widget_show (label7);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook1), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook1), 0), label7);

  notebook2 = gtk_notebook_new ();
  gtk_widget_show (notebook2);
  gtk_container_add (GTK_CONTAINER (notebook1), notebook2);

  fixed3 = gtk_fixed_new ();
  gtk_widget_show (fixed3);
  gtk_container_add (GTK_CONTAINER (notebook2), fixed3);

  fixed4 = gtk_fixed_new ();
  gtk_widget_show (fixed4);
  gtk_fixed_put (GTK_FIXED (fixed3), fixed4, 456, 112);
  gtk_widget_set_size_request (fixed4, 50, 50);

  spinbutton1_adj = gtk_adjustment_new (1, 1, 31, 1, 10, 10);
  spinbutton1 = gtk_spin_button_new (GTK_ADJUSTMENT (spinbutton1_adj), 1, 0);
  gtk_widget_show (spinbutton1);
  gtk_fixed_put (GTK_FIXED (fixed3), spinbutton1, 248, 8);
  gtk_widget_set_size_request (spinbutton1, 60, 27);

  label25 = gtk_label_new (_("Day:"));
  gtk_widget_show (label25);
  gtk_fixed_put (GTK_FIXED (fixed3), label25, 200, 16);
  gtk_widget_set_size_request (label25, 49, 17);

  label24 = gtk_label_new (_("Date of reservation"));
  gtk_widget_show (label24);
  gtk_fixed_put (GTK_FIXED (fixed3), label24, 40, 16);
  gtk_widget_set_size_request (label24, 137, 24);

  label26 = gtk_label_new (_("Month:"));
  gtk_widget_show (label26);
  gtk_fixed_put (GTK_FIXED (fixed3), label26, 320, 16);
  gtk_widget_set_size_request (label26, 49, 17);

  label27 = gtk_label_new (_("Year:"));
  gtk_widget_show (label27);
  gtk_fixed_put (GTK_FIXED (fixed3), label27, 448, 16);
  gtk_widget_set_size_request (label27, 49, 17);

  spinbutton2_adj = gtk_adjustment_new (1, 1, 31, 1, 10, 10);
  spinbutton2 = gtk_spin_button_new (GTK_ADJUSTMENT (spinbutton2_adj), 1, 0);
  gtk_widget_show (spinbutton2);
  gtk_fixed_put (GTK_FIXED (fixed3), spinbutton2, 384, 8);
  gtk_widget_set_size_request (spinbutton2, 60, 27);

  spinbutton3_adj = gtk_adjustment_new (1, 2018, 2020, 1, 10, 10);
  spinbutton3 = gtk_spin_button_new (GTK_ADJUSTMENT (spinbutton3_adj), 1, 0);
  gtk_widget_show (spinbutton3);
  gtk_fixed_put (GTK_FIXED (fixed3), spinbutton3, 504, 8);
  gtk_widget_set_size_request (spinbutton3, 60, 27);

  label28 = gtk_label_new (_("Booking time:"));
  gtk_widget_show (label28);
  gtk_fixed_put (GTK_FIXED (fixed3), label28, 64, 80);
  gtk_widget_set_size_request (label28, 121, 16);

  combobox1 = gtk_combo_box_new_text ();
  gtk_widget_show (combobox1);
  gtk_fixed_put (GTK_FIXED (fixed3), combobox1, 193, 70);
  gtk_widget_set_size_request (combobox1, 220, 31);
  gtk_combo_box_append_text (GTK_COMBO_BOX (combobox1), _("9h==>12h"));
  gtk_combo_box_append_text (GTK_COMBO_BOX (combobox1), _("14h==>17h"));

  button5 = gtk_button_new_with_mnemonic (_("Validate"));
  gtk_widget_show (button5);
  gtk_fixed_put (GTK_FIXED (fixed3), button5, 232, 120);
  gtk_widget_set_size_request (button5, 98, 24);

  label29 = gtk_label_new ("");
  gtk_widget_show (label29);
  gtk_fixed_put (GTK_FIXED (fixed3), label29, 200, 160);
  gtk_widget_set_size_request (label29, 169, 32);

  treeview1 = gtk_tree_view_new ();
  gtk_widget_show (treeview1);
  gtk_fixed_put (GTK_FIXED (fixed3), treeview1, 692, 98);
  gtk_widget_set_size_request (treeview1, 300, 200);

  button6 = gtk_button_new_with_mnemonic (_("View dates"));
  gtk_widget_show (button6);
  gtk_fixed_put (GTK_FIXED (fixed3), button6, 760, 312);
  gtk_widget_set_size_request (button6, 138, 32);

  label21 = gtk_label_new (_("Book a date"));
  gtk_widget_show (label21);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook2), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook2), 0), label21);

  empty_notebook_page = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (empty_notebook_page);
  gtk_container_add (GTK_CONTAINER (notebook2), empty_notebook_page);

  label22 = gtk_label_new (_("Change the date"));
  gtk_widget_show (label22);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook2), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook2), 1), label22);

  empty_notebook_page = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (empty_notebook_page);
  gtk_container_add (GTK_CONTAINER (notebook2), empty_notebook_page);

  label23 = gtk_label_new (_("Delete the date "));
  gtk_widget_show (label23);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook2), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook2), 2), label23);

  label8 = gtk_label_new (_("Schedule"));
  gtk_widget_show (label8);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook1), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook1), 1), label8);

  empty_notebook_page = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (empty_notebook_page);
  gtk_container_add (GTK_CONTAINER (notebook1), empty_notebook_page);

  label9 = gtk_label_new (_("Consult files of the members"));
  gtk_widget_show (label9);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook1), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook1), 2), label9);

  empty_notebook_page = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (empty_notebook_page);
  gtk_container_add (GTK_CONTAINER (notebook1), empty_notebook_page);

  label10 = gtk_label_new (_("View"));
  gtk_widget_show (label10);
  gtk_notebook_set_tab_label (GTK_NOTEBOOK (notebook1), gtk_notebook_get_nth_page (GTK_NOTEBOOK (notebook1), 3), label10);

  g_signal_connect ((gpointer) button5, "clicked",
                    G_CALLBACK (on_button5_clicked),
                    NULL);
  g_signal_connect ((gpointer) button6, "clicked",
                    G_CALLBACK (on_button6_clicked),
                    NULL);

  /* Store pointers to all widgets, for use by lookup_widget(). */
  GLADE_HOOKUP_OBJECT_NO_REF (window2, window2, "window2");
  GLADE_HOOKUP_OBJECT (window2, notebook1, "notebook1");
  GLADE_HOOKUP_OBJECT (window2, fixed2, "fixed2");
  GLADE_HOOKUP_OBJECT (window2, label11, "label11");
  GLADE_HOOKUP_OBJECT (window2, button4, "button4");
  GLADE_HOOKUP_OBJECT (window2, label12, "label12");
  GLADE_HOOKUP_OBJECT (window2, label13, "label13");
  GLADE_HOOKUP_OBJECT (window2, label15, "label15");
  GLADE_HOOKUP_OBJECT (window2, label14, "label14");
  GLADE_HOOKUP_OBJECT (window2, label20, "label20");
  GLADE_HOOKUP_OBJECT (window2, label16, "label16");
  GLADE_HOOKUP_OBJECT (window2, label17, "label17");
  GLADE_HOOKUP_OBJECT (window2, label18, "label18");
  GLADE_HOOKUP_OBJECT (window2, label19, "label19");
  GLADE_HOOKUP_OBJECT (window2, label30, "label30");
  GLADE_HOOKUP_OBJECT (window2, label31, "label31");
  GLADE_HOOKUP_OBJECT (window2, label32, "label32");
  GLADE_HOOKUP_OBJECT (window2, label34, "label34");
  GLADE_HOOKUP_OBJECT (window2, label33, "label33");
  GLADE_HOOKUP_OBJECT (window2, label7, "label7");
  GLADE_HOOKUP_OBJECT (window2, notebook2, "notebook2");
  GLADE_HOOKUP_OBJECT (window2, fixed3, "fixed3");
  GLADE_HOOKUP_OBJECT (window2, fixed4, "fixed4");
  GLADE_HOOKUP_OBJECT (window2, spinbutton1, "spinbutton1");
  GLADE_HOOKUP_OBJECT (window2, label25, "label25");
  GLADE_HOOKUP_OBJECT (window2, label24, "label24");
  GLADE_HOOKUP_OBJECT (window2, label26, "label26");
  GLADE_HOOKUP_OBJECT (window2, label27, "label27");
  GLADE_HOOKUP_OBJECT (window2, spinbutton2, "spinbutton2");
  GLADE_HOOKUP_OBJECT (window2, spinbutton3, "spinbutton3");
  GLADE_HOOKUP_OBJECT (window2, label28, "label28");
  GLADE_HOOKUP_OBJECT (window2, combobox1, "combobox1");
  GLADE_HOOKUP_OBJECT (window2, button5, "button5");
  GLADE_HOOKUP_OBJECT (window2, label29, "label29");
  GLADE_HOOKUP_OBJECT (window2, treeview1, "treeview1");
  GLADE_HOOKUP_OBJECT (window2, button6, "button6");
  GLADE_HOOKUP_OBJECT (window2, label21, "label21");
  GLADE_HOOKUP_OBJECT (window2, label22, "label22");
  GLADE_HOOKUP_OBJECT (window2, label23, "label23");
  GLADE_HOOKUP_OBJECT (window2, label8, "label8");
  GLADE_HOOKUP_OBJECT (window2, label9, "label9");
  GLADE_HOOKUP_OBJECT (window2, label10, "label10");

  return window2;
}

