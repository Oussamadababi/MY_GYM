#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>

#include <gdk/gdkkeysyms.h>
#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"

create_window_admin (char ch1[20]);
void
on_button8_clicked                     (GtkWidget       *button,
                                        gpointer         user_data,char ch1[20]);
void
on_button11_clicked                    (GtkWidget      *button,
                                        gpointer         user_data,char ch1[20]);
void
on_button10_clicked                    (GtkWidget       *button,
                                        gpointer         user_data,char ch1[20]);
void on_button5_clicked (GtkWidget       *button,gpointer         user_data,char ch1[20]);
