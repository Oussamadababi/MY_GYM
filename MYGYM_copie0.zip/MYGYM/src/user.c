#include <stdio.h>
#include <stdlib.h>
#include "user.h"
#include <gtk/gtk.h>

enum
{
  USER,
  PASS,
  FUNC,
  COLUMNS
};

void add_user(user p,GtkWidget *output,GtkWidget *input1,GtkWidget *input2)
{
	FILE *f;
	char user[20],pass[20],fun[20];
	int i=0;
	f=fopen("user.txt","a+");
	if(f!=NULL)
		
	{	
		while (fscanf(f,"%s %s %s",user,pass,fun)!=EOF && ((strcmp(p.username,user)!=0 && (strcmp(p.func,pass)!=0))))
			{
				
	
				i++;

			}
		if (strcmp(p.username,user)==0 && (strcmp(p.func,fun)==0))
					{gtk_label_set_text(GTK_LABEL(output),"user is already signed !!!");
					gtk_entry_set_text(GTK_ENTRY(input1),"");
					gtk_entry_set_text(GTK_ENTRY(input2),"");
					}

		 else
			{fprintf(f,"%s %s %s\n",p.username,p.password,p.func);
			gtk_label_set_text(GTK_LABEL(output),"user succefuly added !!!");
			}
		fclose(f);
	}
}
//show
void show_user(GtkWidget *list)
{
	GtkCellRenderer *rend;
	GtkTreeViewColumn *col;
	GtkTreeIter iter;
	GtkTreeStore *store;
	char username[30];
	char password[20];
	char func[20];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model(list);
	if (store==NULL)
	{
		rend= gtk_cell_renderer_text_new();
		col=gtk_tree_view_column_new_with_attributes(" usernames",rend,"text",USER,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (list),col);
		rend= gtk_cell_renderer_text_new();
		col=gtk_tree_view_column_new_with_attributes(" passwords",rend,"text",PASS,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (list),col);
		rend= gtk_cell_renderer_text_new();
		col=gtk_tree_view_column_new_with_attributes(" functions",rend,"text",FUNC,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (list),col);
	}
	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("user.txt","r");
	if (f!=NULL)
	{
		//f=fopen("users.txt","r");
		while(fscanf(f,"%s %s %s \n",username,password,func)!=EOF)
		{	
			gtk_list_store_append (store,&iter);
			gtk_list_store_set (store,&iter,USER,username,PASS,password,FUNC,func,-1);
		}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(list),GTK_TREE_MODEL(store));
	g_object_unref (store);
	}
}
void delete_user(user p,GtkWidget *output)
{
    FILE *f1, *f2;
    char user[20],pass[20],fun[20];
    f1 = fopen("user.txt", "r");
    f2 = fopen("replica.c", "w");
    
    while (fscanf(f1,"%s %s %s",user,pass,fun)!=EOF)
    {
        
        if ((strcmp(p.password,pass)!=0) && (strcmp(p.username,user)!=0) && (strcmp(p.func,pass)!=0))
            
            {
                fprintf(f2,"%s %s %s\n",user,pass,fun);
            }
    }
    fclose(f1);
    fclose(f2);
    remove("user.txt");
    rename("replica.c", "user.txt");
    gtk_label_set_text(GTK_LABEL(output),"user succefuly deleted !!!");
}
